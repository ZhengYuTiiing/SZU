/****************************************************/
/* File: parse.c                                    */
/* The parser implementation for the TINY compiler  */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "globals.h"
#include "util.h"
#include "scan.h"
#include "parse.h"

static TokenType token; /* holds current token */

/* function prototypes for recursive calls */
static TreeNode * stmt_sequence(void);
static TreeNode * statement(void);
static TreeNode * if_stmt(void);
static TreeNode * repeat_stmt(void);
static TreeNode * assign_stmt(void);
static TreeNode * read_stmt(void);
static TreeNode * write_stmt(void);
static TreeNode * while_stmt(void);
static TreeNode * boolexp(void);
static TreeNode * exp(void);
static TreeNode * simple_exp(void);
static TreeNode * term(void);
static TreeNode * factor(void);
static TreeNode * declarations(void);
static TreeNode * decl(void);
static TreeNode * varlist(void);

static void syntaxError(char * message)
{ fprintf(listing,"\n>>> ");
  fprintf(listing,"Syntax error at line %d: %s",lineno,message);
  Error = TRUE;
}

static void match(TokenType expected)
{ if (token == expected) token = getToken();
  else {
    syntaxError("unexpected token -> ");
    printToken(token,tokenString);
    fprintf(listing,"      ");
  }
}

TreeNode * declarations(void)
{
    TreeNode * t =NULL;
    TreeNode *p=t;
    while ((token==STRING)||(token==INT)||(token==BOOL) )
    {   TreeNode *q=decl();
        if (q!=NULL) {
            if (t==NULL) t = p = q;
            else /* now p cannot be NULL either */
            { p->sibling = q;
                p = q;
            }
        }
    }
    return t;
}

TreeNode * decl(void)
{
    TreeNode * t =NULL;
    switch (token) {
        case INT :
            t = newDeclNode(IntK);
            match(INT);
            break;
        case BOOL :
            t = newDeclNode(BoolK);
            match(BOOL);
            break;
        case STRING :
            t = newDeclNode(StringK);
            match(STRING);
            break;
        default : syntaxError("unexpected token -> ");
            printToken(token,tokenString);
            token = getToken();
            break;
    } /* end case */
    t->child[0]=varlist();
    match(SEMI);
    return t;
}
TreeNode * varlist(void){
    TreeNode * t = newExpNode(IdK);
    if ((t!=NULL) && (token==ID))     t->attr.name = copyString(tokenString);
    match(ID);
    if (token==COMMA)
    {
        match(COMMA);
        t->child[0] = varlist();
    }
    return t;
}
TreeNode * stmt_sequence(void)
{ TreeNode * t = statement();
  TreeNode * p = t;
  while ((token!=ENDFILE) && (token!=END) &&
         (token!=ELSE) && (token!=UNTIL)&&(token!=WHILE))
  {
      TreeNode * q;
    match(SEMI);
    q = statement();
    if (q!=NULL) {
      if (t==NULL) t = p = q;
      else /* now p cannot be NULL either */
      { p->sibling = q;
        p = q;
      }
    }
  }
  return t;
}

TreeNode * statement(void)
{ TreeNode * t = NULL;
  switch (token) {
    case IF : t = if_stmt(); break;
    case REPEAT : t = repeat_stmt(); break;
    case ID : t = assign_stmt(); break;
    case READ : t = read_stmt(); break;
    case WRITE : t = write_stmt(); break;
    case DO: t = while_stmt(); break;
    default : syntaxError("unexpected token -> ");
              printToken(token,tokenString);
              token = getToken();
              break;
  } /* end case */
  return t;
}

TreeNode * if_stmt(void)
{ TreeNode * t = newStmtNode(IfK);
  match(IF);
  if (t!=NULL) t->child[0] = boolexp();
  match(THEN);
  if (t!=NULL) t->child[1] = stmt_sequence();
  if (token==ELSE) {
    match(ELSE);
    if (t!=NULL) t->child[2] = stmt_sequence();
  }
  match(END);
  return t;
}

TreeNode * repeat_stmt(void)
{ TreeNode * t = newStmtNode(RepeatK);
  match(REPEAT);
  if (t!=NULL) t->child[0] = stmt_sequence();
  match(UNTIL);
  if (t!=NULL) t->child[1] = boolexp();
  return t;
}

TreeNode * assign_stmt(void)
{ TreeNode * t = newStmtNode(AssignK);
  if ((t!=NULL) && (token==ID))
    t->attr.name = copyString(tokenString);
  match(ID);
  match(ASSIGN);
  TreeNode * p  = newExpNode(ConstK);
  if(token==STR){

      if ((p!=NULL) && (token==STR)){
          p->attr.name = copyString(tokenString);
          p->type=Sstring;
      }
      match(STR);
      t->child[0] = p;
  }
  else if(token==T_TRUE||token==T_FALSE){
      switch (token) {
          case T_TRUE :
          case T_FALSE :
               p = newExpNode(ConstK);
              if ((p!=NULL) ){
                  p->attr.name = copyString(tokenString);
                  p->type=Boolean;
              }
              if(token==T_FALSE) match(T_FALSE);
              if(token==T_TRUE) match(T_TRUE);
              t->child[0] = p;
              break;
          default:
              syntaxError("unexpected token -> ");
              printToken(token,tokenString);
              token = getToken();
              break;
      }
  }
  else{
      if (t!=NULL) t->child[0] = exp();
  }
  return t;
}

TreeNode * read_stmt(void)
{ TreeNode * t = newStmtNode(ReadK);
  match(READ);
  if ((t!=NULL) && (token==ID))
    t->attr.name = copyString(tokenString);
  match(ID);
  return t;
}

TreeNode * write_stmt(void)
{ TreeNode * t = newStmtNode(WriteK);
  match(WRITE);
  if (t!=NULL) t->child[0] = exp();
  return t;
}

TreeNode * while_stmt(void)
{
    TreeNode * t = newStmtNode(WhileK);
    match(DO);
    if (t!=NULL) t->child[0] = stmt_sequence();
    match(WHILE);
    if (t!=NULL) t->child[1] = boolexp();
    return t;
}
TreeNode * boolexp(void){
    TreeNode * t = exp();
    while ((token==OR)||(token==AND))
    { TreeNode * p = newExpNode(BOOLK);
        if (p!=NULL) {
            p->child[0] = t;
            p->attr.name = copyString(tokenString);
            t = p;
            match(token);
            p->child[1] = exp();
        }
    }
    return t;
}
TreeNode * exp(void)
{ TreeNode * t = simple_exp();
  if ((token==LT)||(token==EQ)||(token==GT)||(token==LTE)||(token==GTE)) {
    TreeNode * p = newExpNode(OpK);
    if (p!=NULL) {
      p->child[0] = t;
      p->attr.op = token;
      t = p;
    }
    match(token);
    if (t!=NULL)
      t->child[1] = simple_exp();
  }
  return t;
}

TreeNode * simple_exp(void)
{ TreeNode * t = term();
  while ((token==PLUS)||(token==MINUS))
  { TreeNode * p = newExpNode(OpK);
    if (p!=NULL) {
      p->child[0] = t;
      p->attr.op = token;
      t = p;
      match(token);
      t->child[1] = term();
    }
  }
  return t;
}

TreeNode * term(void)
{ TreeNode * t = factor();
  while ((token==TIMES)||(token==OVER))
  { TreeNode * p = newExpNode(OpK);
    if (p!=NULL) {
      p->child[0] = t;
      p->attr.op = token;
      t = p;
      match(token);
      p->child[1] = factor();
    }
  }
  return t;
}

TreeNode * factor(void)
{ TreeNode * t = NULL;
  switch (token) {
    case NUM :
      t = newExpNode(ConstK);
      if ((t!=NULL) && (token==NUM)){
          t->attr.val = atoi(tokenString);
          t->type=Integer;
      }
      match(NUM);
      break;
//    case T_TRUE :
//    case T_FALSE :
//          t = newExpNode(ConstK);
//          if ((t!=NULL) ){
//              t->attr.name = copyString(tokenString);
//              t->type=Boolean;
//          }
//          if(token==T_FALSE) match(T_FALSE);
//          if(token==T_TRUE) match(T_TRUE);
//          break;
//    case STR:
//          t = newExpNode(ConstK);
//          if ((t!=NULL) && (token==STR)){
//              t->attr.name = copyString(tokenString);
//              t->type=Sstring;
//          }
//          match(STR);
//          break;

    case ID :
      t = newExpNode(IdK);
      if ((t!=NULL) && (token==ID))
        t->attr.name = copyString(tokenString);
      match(ID);
      break;
    case LPAREN :
      match(LPAREN);
      t = exp();
      match(RPAREN);
      break;

      default:
      syntaxError("unexpected token -> ");
      printToken(token,tokenString);
      token = getToken();
      break;
    }
  return t;
}

/****************************************/
/* the primary function of the parser   */
/****************************************/
/* Function parse returns the newly 
 * constructed syntax tree
 */
TreeNode * parse(void)
{
    TreeNode * root=newRootNode();
    token = getToken();
    root->child[0]= declarations();
    root->child[1]= stmt_sequence();
    if (token!=ENDFILE)
    syntaxError("Code ends before file\n");
    return root;
}