#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <cctype>
#include <stack>

using namespace std;

// 分割字符串
vector<string> split(const string& str, char delimiter) {
    vector<string> tokens;
    stringstream ss(str);
    string token;
    while (getline(ss, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}


int toInt(char c){
    int num=0;
    switch(c) {
        case '+': num=0;break;
        case '-': num=1;break;
        case '*': num=2;break;
        case '/': num=3;break;
        case '(': num=4;break;
        case ')': num=5;break;
        case ';': num=6;break;
    }
    return num;
}

//   + - * / ( ) ;
char prio[7][7]={
        '>','>','<','<','<','>','>',
        '>','>','<','<','<','>','>',
        '>','>','>','>','<','>','>',
        '>','>','>','>','<','>','>',
        '<','<','<','<','<','=','0',
        '>','>','>','>','0','>','>',
        '<','<','<','<','<','0','='
};

bool isOp(char c){
    if(c=='+' || c=='-' || c=='*' || c=='/' || c=='(' || c==')'||c==';'){
        return true;
    }
    return false;
}

string removeSpaces(string& input) {
    string result;  // 存储处理后的结果字符串
    // 遍历输入字符串中的每个字符
    for (char c : input) {
        if (!isspace(c)) {  // 判断当前字符是否为空白字符
            result += c;  // 如果不是空白字符，则将其加入结果字符串中
        }
    }
    return result;  // 返回移除空白字符后的结果字符串
}

int main() {
    //string input="a = b + c * e / g; d = f * g;";
    ifstream infile("input.txt");  // 打开输入文件
    if (!infile) {
        cerr << "无法打开输入文件 input.txt" << endl;
        return 1;
    }
    string input;
    getline(infile, input);  // 从文件中读取一行作为输入
    infile.close();  // 关闭文件

    ofstream outfile("output.txt"); // 打开输出文件
    if (!outfile) {
        cerr << "无法创建或打开输出文件 output.txt" << endl;
        return 1;
    }


    input = removeSpaces(input);
    vector<string> statements = split(input, ';');
    int num =1;
    for (string statement: statements) {
        statement+=';';
      //  string trimmed_statement = removeSpaces(statement);
        stack<string> OPND;
        stack<char> OPTR;
        OPTR.push(';');
        string left= split(statement, '=')[0];
        string right= split(statement, '=')[1];

        char c;

        for (int j = 0; j < right.size(); j++) {
            char token = right[j];
            if (!isOp(token)) {
                OPND.push(std::string(1, token));
            } else {
                char top = OPTR.top();
                switch (prio[toInt(top)][toInt(token)]) {
                    case '<':
                        OPTR.push(token);
                        break;
                    case '=':
                        OPTR.pop();
                        break;
                    case '>':
                    {
                        std::string behind = OPND.top();
                        OPND.pop();
                        std::string first = OPND.top();
                        OPND.pop();
                        char op = OPTR.top();
                        OPTR.pop();
                        std::string line;
                        line = "t" + std::to_string(num) + "=" + first + op + behind + ";";
                        outfile << line << endl;
                        OPND.push("t" + std::to_string(num));
                        num++;
                        j--;
                        break;
                    }
                    case '0':
                        outfile << "表达式错误！ "<<  endl;
                        break;

                }
            }
        }
        string ans;
        ans=left+'='+'t'+ to_string(--num);
        outfile <<ans<<endl;
        num++;
    }
    outfile.close(); // 关闭输出文件
    return 0;
}
