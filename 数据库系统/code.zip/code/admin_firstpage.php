<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理端</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: white;
            padding: 20px;
            font-size: 24px;
        }

        main {
            max-width: 600px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        a {
            display: block;
            margin: 10px 0;
            padding: 10px;
            background-color: #333;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <header>
        管理端
    </header>
    <main>
        <?php
        include 'conn4.php';
        // 获取表名数组
        $tableNames = getTableNames();

        // 遍历数组创建链接
        foreach ($tableNames as $tableName) {
            echo '<a href="' . $tableName . '.php">' . $tableName . '</a>';
        }
        ?>
    </main>
</body>
</html>
