<?php
include 'conn4.php';

// 初始化错误消息和成功消息
$errorMessage = $successMessage = "";

// 初始化各个输入字段的值
$name = $color = $manufacturer = $pricePerDay = $type = $imagePath = "";

// 处理表单提交
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取用户输入
    $name = isset($_POST["name"]) ? $_POST["name"] : "";
    $color = isset($_POST["color"]) ? $_POST["color"] : "";
    $manufacturer = isset($_POST["manufacturer"]) ? $_POST["manufacturer"] : "";
    $pricePerDay = isset($_POST["pricePerDay"]) ? $_POST["pricePerDay"] : "";
    $type = isset($_POST["type"]) ? $_POST["type"] : "";
    $imagePath = isset($_POST["imagePath"]) ? $_POST["imagePath"] : "";

    // 检查是否有输入为空
    if (empty($name) || empty($color) || empty($manufacturer) || empty($pricePerDay) || empty($type) || empty($imagePath)) {
        $errorMessage = "请填写所有字段";
    } else {
        // 调用存储过程
        $sql = "CALL add_bag('$name', '$color', '$manufacturer', $pricePerDay, '$type', 1, '$imagePath')";
        $result = $conn->query($sql);

        if ($result === false) {
            $errorMessage = "添加失败: " . $conn->error;
        } else {
            $successMessage = "包添加成功！";
        }
    }
}

// 关闭数据库连接
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>添加包</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: white;
            padding: 20px;
            font-size: 24px;
        }

        main {
            max-width: 400px; /* 调整整个表单的宽度 */
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            margin-bottom: 8px;
            width: 100%;
            text-align: left;
        }

        input {
            margin-bottom: 16px;
            padding: 8px;
            width: 100%;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 60%; /* 使按钮宽度为50% */
            margin-bottom: 10px; /* 添加一些底边距 */
        }

        button:hover {
            background-color: #555;
        }

        .error-message {
            color: red;
            margin-top: 16px;
        }

        .success-message {
            color: green;
            margin-top: 16px;
        }

        .return-button {
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 60%; /* 使按钮宽度为50% */
        }

        .return-button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <header>
        Add Bags
    </header>
    <main>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="name">包名：</label>
            <input type="text" name="name" placeholder="eg:Claudia" required value="<?php echo $name; ?>">

            <label for="color">颜色：</label>
            <input type="text" name="color" placeholder="eg:Blue" required value="<?php echo $color; ?>">

            <label for="manufacturer">厂商：</label>
            <input type="text" name="manufacturer" placeholder="eg:Coach" required value="<?php echo $manufacturer; ?>">

            <label for="pricePerDay">价格：</label>
            <input type="number" name="pricePerDay" placeholder="eg:10" step="0.01" required value="<?php echo $pricePerDay; ?>">

            <label for="type">类型：</label>
            <input type="text" name="type" placeholder="eg:Bucket" required value="<?php echo $type; ?>">

            <label for="imagePath">路径：</label>
            <input type="text" name="imagePath" placeholder="eg:image11.jpg" required value="<?php echo $imagePath; ?>">

            <button type="submit">确定</button>
            <button class="return-button" onclick="window.location.href='handbags.php'">返回</button>
        </form>

        <?php
        // 显示错误或成功消息
        if (!empty($errorMessage)) {
            echo "<p class='error-message'>$errorMessage</p>";
        }

        if (!empty($successMessage)) {
            echo "<p class='success-message'>$successMessage</p>";
        }
        ?>
    </main>
</body>
</html>
