<?php 
$hostname = "localhost"; //主机名,可以用IP代替
$database = "luxury"; //数据库名
$username = "ZhengYuting"; //数据库用户名
$password = "zyt1566585M"; //数据库密码
$conn = new mysqli($hostname, $username, $password, $database);
if ($conn->connect_error) {
    die("连接数据库失败: " . $conn->connect_error);
}
// 获取表的属性（字段名）
function getTableAttributes($tableName) {
    global $conn;
    $attributes = array();

    $sql = "DESCRIBE $tableName";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $attributes[] = $row['Field'];
        }
    }

    return $attributes;
}

// 获取表的项数
function getTableRowCount($tableName) {
    global $conn;

    $sql = "SELECT COUNT(*) as count FROM $tableName";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count'];
    }

    return 0;
}
function setPrimaryKey($tableName)
{
    global $conn;
    global $primaryKey;
    $sql = "SHOW INDEX FROM $tableName";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $primaryKey = $row['Column_name'];
}

function getTableNames()
{
    global $conn;
    $sql = "SHOW TABLES";
    $result = $conn->query($sql);
    $tableNames = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tableNames[] = $row['Tables_in_' . $GLOBALS['database']];
        }
    }

    return $tableNames;
}

function getTableData($tableName, $data)
{
    global $conn;
    if( empty($data["condition"]) || strlen($data["condition"]) == 0){
        $sql = "SELECT * FROM $tableName ";
    }
    else{
        $values = $data["condition"];
        $sql = "SELECT * FROM $tableName WHERE $values";
    }
    $result = $conn->query($sql);
    $tableData = array();
    if(empty($result)) return [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tableData[] = $row;
        }
    }
    return $tableData;
}

function insertRecord($tableName, $data)
{
    global $conn;
    $keys = implode(', ', array_keys($data));
    $values = "'" . implode("', '", array_values($data)) . "'";
    $sql = "INSERT INTO $tableName ($keys) VALUES ($values)";
    $result = $conn->query($sql);
    if ($result) {
        echo "数据添加成功!";
    } else {
        echo '<script>alert("数据添加失败: ' . $conn->error . '");</script>';
    }
    return $result;
}

function deleteRecord($tableName, $id)
{
    global $conn;
    global $primaryKey;
    $sql = "DELETE FROM $tableName WHERE $primaryKey = '$id'";
    $result = $conn->query($sql);
    if ($result) {
        echo "数据删除成功!";
    } else {
        echo '<script>alert("数据删除失败: ' . $conn->error . '");</script>';
    }
    return $result;
}

function updateRecord($tableName, $id, $data)
{
    global $conn;
    global $primaryKey;
    $set = "";
    foreach ($data as $key => $value) {
        $set .= "$key = '$value', ";
    }
    $set = rtrim($set, ', ');
    $sql = "UPDATE $tableName SET $set WHERE $primaryKey = '$id'";
    $result = $conn->query($sql);
    if ($result) {
        echo "数据更新成功!";
    } else {
        echo '<script>alert("数据更新失败: ' . $conn->error . '");</script>';
    }
    
    return $result;
}
function getTableHeader($tableName) {
    global $conn;
    $sql = "DESCRIBE $tableName";
    $result = $conn->query($sql);
    $tableHeader = array();

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $tableHeader[] = $row['Field'];
        }
    }

    return $tableHeader;
}
?>