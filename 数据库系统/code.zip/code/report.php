<?php
include 'conn4.php';
session_start();
if (!isset($_SESSION['customerID'])) {
    header("Location: login4.php");
    exit();
}

$customerID = $_SESSION['customerID'];
$lastName = $_SESSION['lastName'];
$firstName = $_SESSION['firstName'];
// 调用存储过程
$sql = "CALL report_customer_amount('$customerID')";
$result = $conn->multi_query($sql);

echo "
<!DOCTYPE html>
<html>
<head>
    <title>Customer Report</title>
    <style>
        /* 样式内容，可以根据需要自行调整 */
        body {
            font-family: Arial, sans-serif;
            margin:20px;
            padding: 0;
            background-color: white;
        }
        h2, h3 {
            color: #333;
        }

        .report-container {
            max-width: 600px;
            margin: 0 auto;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        nav {
            background-color: #333;
            overflow: hidden;
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        .user-name {
            color: white;
            margin-right: 0;
            font-weight: bold;
            float: right; /* 将用户姓名向右浮动 */
        }
    </style>
</head>
<body>
    <nav>
        <a href='index4.php'>Rent</a>
        <a href='mybags4.php'>Return</a>
        <a href='report.php'>Report</a>
        <p  class='user-name'>$firstName $lastName</p>
    </nav>
    <div class='report-container'>
";

// 处理第一个结果集，获取顾客信息
if ($result) {
    $customerInfo = $conn->store_result()->fetch_assoc();
    echo "<h3>Customer Name: " . $customerInfo['FirstName'] . ' ' . $customerInfo['LastName'] . "</h3>";
} else {
    echo "Error retrieving customer information: " . $conn->error;
}

// 移到下一个结果集（第二个结果集），获取租借的包信息和费用
if ($conn->next_result()) {
    $rentalsResult = $conn->store_result();

    if ($rentalsResult) {

        echo "<table border='1'>";
        echo "<tr><th>Manufacturer</th><th>Name</th><th>Cost</th></tr>";
        while ($row = $rentalsResult->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['ManufacturerName'] . "</td>";
            echo "<td>" . $row['HandbagName'] . "</td>";
            echo "<td>$" . $row['Cost'] . "</td>";
            echo "</tr>";
        }
        echo "</table><br>";
    } else {
        echo "Error retrieving rentals information: " . $conn->error;
    }
}

// 移到下一个结果集（第三个结果集），获取租借的总费用
if ($conn->next_result()) {
    $totalCostResult = $conn->store_result();

    if ($totalCostResult) {
        $totalCost = $totalCostResult->fetch_assoc()['TotalCost'];
        echo "<h3>Total Rental Cost: $" . $totalCost . "</h3>";
    } else {
        echo "Error retrieving total cost information: " . $conn->error;
    }
}

// 输出 HTML 尾部
echo "
    </div>
</body>
</html>
";

// 关闭数据库连接
$conn->close();
?>
