<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理端 - Customers</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: white;
            padding: 20px;
            font-size: 24px;
        }

        main {
            max-width: 1000px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

                form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .best-customers-button,
        .return-button {
            width: 500px; /* Adjust the width as needed */
            display: block;
            margin: 10px 0;
            padding: 10px;
            background-color: #333;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

    </style>
</head>
<body>
    <header>
        管理端 - Customers
    </header>
    <main>
        <h1>Customers 表</h1>
        <?php
        include 'conn4.php';

        $tableName = "Customers";

        // 获取Customers表的属性（字段名）
        $attributes = getTableAttributes($tableName);

        // 获取Customers表的数据
        $sql = "SELECT * FROM $tableName";
        $result = $conn->query($sql);

        // 检查是否有数据
        if ($result->num_rows > 0) {
            // 输出表格
            echo "<table border='1'><tr>";
            foreach ($attributes as $attribute) {
                echo "<th>$attribute</th>";
            }
            echo "</tr>";

            // 输出数据
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                foreach ($attributes as $attribute) {
                    echo "<td>{$row[$attribute]}</td>";
                }
                echo "</tr>";
            }

            // 输出表尾
            echo "</table>";

            // 添加调用存储过程的按钮
            echo "<form method='post' action='bestcustomer.php'>
            <input type='submit' name='submit' value='Best Customers' class='best-customers-button'>
            
            </form>";

            // 返回首页的按钮
            echo "<form method='get' action='admin_firstpage.php'>
            <input type='submit' value='返回首页' class='return-button'>
                  </form>";
        } else {
            echo "No records found";
        }

        // 关闭数据库连接
        $conn->close();
        ?>
    </main>
</body>
</html>
