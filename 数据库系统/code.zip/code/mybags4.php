<?php
include 'conn4.php';
// 在每个页面开始时都要启动 Session
session_start();
// 检查用户是否已登录，如果没有登录，则跳转到登录页面
if (!isset($_SESSION['customerID'])) {
    header("Location: login4.php");
    exit();
}
// 获取用户信息
$customerID = $_SESSION['customerID'];
$lastName = $_SESSION['lastName'];
$firstName = $_SESSION['firstName'];
// 处理归还
// 处理归还
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['returnBagID'])) {
    $returnBagID = $_POST['returnBagID'];
    // 调用存储过程完成包包的归还
    $sql = "CALL return_bag($returnBagID)";
    $conn->query($sql);
    $sql = "SELECT 
                (h.PricePerDay + IF(r.OptionalInsurance, 1, 0)) * DATEDIFF(r.DateReturned, r.DateRented)  AS Cost,
                DATEDIFF(r.DateReturned, r.DateRented) AS RentalDays
            FROM Rentals r
            JOIN handbags h ON r.bagID = h.bagid
            WHERE r.CustomerID = '$customerID'
                AND r.bagID= $returnBagID
                AND h.bagid= $returnBagID;";
    // 执行查询
    $result = $conn->query($sql);
    $RentalCost = 0;
    $RentalDay = 0;
    if ($result->num_rows > 0) {
        // 从结果集中获取费用
        while ($row = $result->fetch_assoc()) {
            $RentalCost = $row['Cost'];
            $RentalDay = $row['RentalDays'];
        }
        echo "<script>alert('Handbag returned successfully! \\nRent ".$RentalDay." days. Rental cost: $".$RentalCost."');</script>";
    }
}



// 调用存储过程获取用户租借但尚未归还的包包
$sql = "CALL get_user_rentals('$customerID')";
$result = $conn->query($sql);

// 关闭数据库连接
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Rentals</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin:20px;
            padding: 0;
            background-color: white;
        }

        nav {
            background-color: #333;
            overflow: hidden;
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        .card {
            border: 1px solid #ccc;
            padding: 10px;
            margin: 10px;
            width: 300px;
            display: inline-block;
            position: relative;
        }

        .card img {
            width: 100%;
            height: auto;
        }

        .card-text {
            font-size: 14px;
        }

        .availability {
            position: absolute;
            bottom: 5px;
            right: 5px;
        }

        .rent-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            cursor: pointer;
        }

        .unavailable-button {
            background-color: #808080;
            color: white;
            border: none;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            cursor: not-allowed;
        }

        #rentDialog {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        #rentDialog button {
            margin-top: 10px;
            cursor: pointer;
        }
        .user-name {
            color: white;
            margin-right: 0;
            font-weight: bold;
            float: right; /* 将用户姓名向右浮动 */
        }
    </style>
    <script>
        function confirmReturn(bagID, bagName) {
            var confirmation = confirm("Are you sure you want to return the bag: " + bagName + "?");
            if (confirmation) {
                // 使用 form 元素提交表单，将 returnBagID 作为表单字段传递
                var form = document.createElement("form");
                form.method = "POST";
                form.action = "mybags4.php";

                var input = document.createElement("input");
                input.type = "hidden";
                input.name = "returnBagID";
                input.value = bagID;

                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</head>
<body>
    <!-- Top Navigation Bar -->
    <nav>
        <a href="index4.php">Rent</a>
        <a href="mybags4.php">Return</a>
        <a href='report.php'>Report</a>
        <p class='user-name'><?php echo $firstName . ' ' . $lastName; ?></p>
    </nav>
<?php
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // 输出每个手袋的卡片
        echo "<div class='card'>";
        echo "<img src='{$row["image_path"]}' alt='Handbag Image'>";
        echo "<h3>{$row["Name"]}</h3>";
        echo "<p class='card-text'>Designer: {$row["Manufacturer"]}</p>";
        echo "<p class='card-text'>Color: {$row["Color"]}</p>";
        echo "<p class='card-text'>Price Per Day: {$row["PricePerDay"]}</p>";
        echo "<button class='return-button' onclick='confirmReturn({$row["BagID"]}, \"{$row["Name"]}\")'>Return</button>";
        echo "</div>";
    }
} else {
    echo "There are currently no unreturned bags";
}
?>
</body>
</html>
