<?php
include 'conn4.php'; // 请确保包含数据库连接文件

// 初始化变量
$manufacturerResults = []; // 用于存储制造商的结果
$searchMessage = ''; // 存储搜索结果消息

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 处理用户提交的表单
    if (isset($_POST['manufacturer']) && !empty($_POST['manufacturer'])) {
        $manufacturer = $_POST['manufacturer'];
        // 调用存储过程
        $sql = "CALL BagsbyManufacturer(?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $manufacturer);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            // 将结果存储到数组中
            while ($row = $result->fetch_assoc()) {
                $manufacturerResults[] = $row;
            }
        } else {
            $searchMessage = 'No results found.Check for spelling errors';
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bags by Manufacturer</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: white;
            padding: 20px;
            font-size: 24px;
        }

        main {
            max-width: 500px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            margin-bottom: 8px;
            width: 100%;
            text-align: left;
        }

        input {
            margin-bottom: 16px;
            padding: 8px;
            width: 100%;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 50%;
        }

        button:hover {
            background-color: #555;
        }

        .search-message {
            color: red;
            margin-top: 16px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .return-button {
            width: 50%; /* Adjust the width as needed */
            display: block;
            margin: 10px 0;
            padding: 10px;
            background-color: #333;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .return-button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <header>
        Bags by Manufacturer
    </header>
    <main>
        <!-- Search Form -->
        <form action="" method="post">
            <label for="manufacturer">Manufacturer:</label>
            <input type="text" name="manufacturer" required>
            <button type="submit">Search</button>
            <?php
            // Show search message
            if (!empty($searchMessage)) {
                echo '<p class="search-message">' . $searchMessage . '</p>';
            }
            ?>
        </form>

        <!-- Search Results -->
        <?php
        if (!empty($manufacturerResults)) {
            echo "<h2>Search Results</h2>";

            // 输出表格
            echo "<table border='1'><tr><th>Name</th><th>Color</th><th>Manufacturer</th></tr>";

            // 输出数据
            foreach ($manufacturerResults as $row) {
                echo "<tr><td>{$row['Name']}</td><td>{$row['Color']}</td><td>{$row['Manufacturer']}</td></tr>";
            }

            // 输出表尾
            echo "</table>";
        }
        ?>

        <!-- 返回按钮 -->
        <form method="get" action="handbags.php">
            <input type="submit" value="返回Handbags" class="return-button">
        </form>
    </main>
</body>
</html>
