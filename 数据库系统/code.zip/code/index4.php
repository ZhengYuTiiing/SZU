<?php
include 'conn4.php';
session_start();
if (!isset($_SESSION['customerID'])) {
    header("Location: login4.php");
    exit();
}
$customerID = $_SESSION['customerID'];
$lastName = $_SESSION['lastName'];
$firstName = $_SESSION['firstName'];
// 处理租借
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['rentBagID'])) {
    $rentBagID = $_POST['rentBagID'];
    $optionalInsurance = isset($_POST['insurance']) ? 1 : 0;
    // 使用存储过程调用来插入租借记录
    $sql = "CALL add_rentals('$customerID', $rentBagID, $optionalInsurance)";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    // 显示租借成功的弹窗
    echo "<script>alert('Handbag rented successfully!'); window.location='index4.php';</script>";
    exit();
}

// 获取查询参数（通过 POST 参数传递过来的）
$filterColors = isset($_POST['colors']) ? $_POST['colors'] : [];
$filterDesigners = isset($_POST['designers']) ? $_POST['designers'] : [];
$filterTypes = isset($_POST['types']) ? $_POST['types'] : [];
// 获取所有不同的颜色、设计师和类型
$colors = $conn->query("SELECT DISTINCT Color FROM handbags")->fetch_all(MYSQLI_ASSOC);
$designers = $conn->query("SELECT DISTINCT Manufacturer AS Designer FROM handbags")->fetch_all(MYSQLI_ASSOC);
$types = $conn->query("SELECT DISTINCT Type FROM handbags")->fetch_all(MYSQLI_ASSOC);
// 构造 SQL 查询语句
$sql = "SELECT * FROM handbags WHERE 1=1";
// 根据过滤条件追加 SQL 查询语句
if (!empty($filterColors)) {
    $sql .= " AND Color IN ('" . implode("','", $filterColors) . "')";
}
if (!empty($filterDesigners)) {
    $sql .= " AND Manufacturer IN ('" . implode("','", $filterDesigners) . "')";
}
if (!empty($filterTypes)) {
    $sql .= " AND Type IN ('" . implode("','", $filterTypes) . "')";
}
$result = $conn->query($sql);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Handbags List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
            background-color: white;
        }

        nav {
            background-color: #333;
            overflow: hidden;
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        .card {
            border: 1px solid #ccc;
            padding: 10px;
            margin: 10px;
            width: 300px;
            display: inline-block;
            position: relative;
        }

        .card img {
            width: 100%;
            height: auto;
        }

        .card-text {
            font-size: 14px;
        }

        .availability {
            position: absolute;
            bottom: 5px;
            right: 5px;
        }

        .rent-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            cursor: pointer;
        }

        .unavailable-button {
            background-color: #808080;
            color: white;
            border: none;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            cursor: not-allowed;
        }

        #rentDialog {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        #rentDialog button {
            margin-top: 10px;
            cursor: pointer;
        }
        .user-name {
            color: white;
            margin-right: 0;
            font-weight: bold;
            float: right; /* 将用户姓名向右浮动 */
        }
    </style>
    <script>
        function showRentDialog(bagID) {
            // 设置隐藏字段中的rentBagID值
            document.getElementById('rentBagID').value = bagID;
            // 显示租借对话框
            document.getElementById('rentDialog').style.display = 'block';
            updateInsuranceCostInfo();
        }

        function hideRentDialog() {
            document.getElementById('rentDialog').style.display = 'none';
        }

        function updateInsuranceCostInfo() {
            var insuranceCheckbox = document.getElementById('insuranceCheckbox');
            var insuranceCostInfo = document.getElementById('insuranceCostInfo');

            if (insuranceCheckbox.checked) {
                insuranceCostInfo.style.display = 'block';
            } else {
                insuranceCostInfo.style.display = 'none';
            }
        }

        function confirmRent() {
            var insuranceCheckbox = document.getElementById('insuranceCheckbox');
            var insuranceCost = insuranceCheckbox.checked ? 1 : 0;

            alert('Handbag rented successfully! Insurance cost: $' + insuranceCost);  // You can customize this part to handle the actual rental process
            hideRentDialog();
        }
    </script>
</head>
<body>
    <!-- Top Navigation Bar -->
    <nav>
        <a href="index4.php">Rent</a>
        <a href="mybags4.php">Return</a>
        <a href='report.php'>Report</a>
        <p class='user-name'><?php echo $firstName . ' ' . $lastName; ?></p>
    </nav>

    <!-- Content Section -->
    <h2>Welcome, <?php echo $firstName . ' ' . $lastName; ?>!</h2>
    <!-- Filter Form -->
    <form method="post" action="index4.php">
        <!-- Color Filter Checkboxes -->
        <p>Filter by Color:
            <?php
            foreach ($colors as $color) {
                echo "<label><input type='checkbox' name='colors[]' value='{$color["Color"]}'>{$color["Color"]}</label>";
            }
            ?>
        </p>

        <!-- Designer Filter Checkboxes -->
        <p>Filter by Designer:
            <?php
            foreach ($designers as $designer) {
                echo "<label><input type='checkbox' name='designers[]' value='{$designer["Designer"]}'>{$designer["Designer"]}</label>";
            }
            ?>
        </p>

        <!-- Type Filter Checkboxes -->
        <p>Filter by Type:
            <?php
            foreach ($types as $type) {
                echo "<label><input type='checkbox' name='types[]' value='{$type["Type"]}'>{$type["Type"]}</label>";
            }
            ?>
        </p>

        <button type="submit">Apply Filters</button>
    </form>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // 输出每个手袋的卡片
            echo "<div class='card'>";
            echo "<img src='{$row["image_path"]}' alt='Handbag Image'>";
            echo "<h3>{$row["Name"]}</h3>";
            echo "<p class='card-text'>Designer: {$row["Manufacturer"]}</p>";
            echo "<p class='card-text'>Color: {$row["Color"]}</p>";
            echo "<p class='card-text'>Price Per Day: {$row["PricePerDay"]}</p>";
            if ($row["available"]) {
                // 修改按钮的onclick属性，传递bagID
                echo "<button class='rent-button' onclick='showRentDialog(\"{$row["BagID"]}\")'>Rent</button>";
            } else {
                echo "<button class='unavailable-button' disabled>Unavailable</button>";
            }
            echo "</div>";
        }
    } else {
        echo "No handbags records found.";
    }
    ?>

    <!-- Rent Dialog -->
    <div id="rentDialog" style="display: none;">
        <h3>Confirm Rent</h3>
        <p>Are you sure you want to rent this handbag?</p>

        <!-- Optional Insurance Checkbox -->
        <form method="post" action="index4.php">
            <label><input type="checkbox" name="insurance"> Optional insurance ($1 per day)</label>
            <p>Optional insurance costs an extra $1 per day.</p>

            <!-- 隐藏字段 -->
            <input type="hidden" name="rentBagID" id="rentBagID" value="">
            <!-- 其他隐藏字段根据需要添加 -->

            <input type="submit" value="Confirm">
            <button type="button" onclick="hideRentDialog()">Cancel</button>
        </form>
    </div>
</body>
</html>
