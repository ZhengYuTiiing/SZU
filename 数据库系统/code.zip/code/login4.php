<?php
include 'conn4.php';

// 初始化变量
$errorMessage = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取用户输入的姓和名
    $lastName = $_POST['lastName'];
    $firstName = $_POST['firstName'];
    // 构造 SQL 查询语句
    $sql = "SELECT * FROM Customers WHERE LastName = '$lastName' AND FirstName = '$firstName'";
    $result = $conn->query($sql);
    // 检查是否有匹配的用户
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    session_start();
    $_SESSION['customerID'] = $row['CustomerID'];
    $_SESSION['lastName'] = $row['LastName'];
    $_SESSION['firstName'] = $row['FirstName'];
    // 如果名字为"Mabel Zheng"，跳转到admin_firstpage.php
    if ($firstName == "Zheng" && $lastName == "Mabel") {
        echo "Debug: Redirecting to admin_firstpage.php";
        header("Location: admin_firstpage.php");
        exit();
    } else {
        // 其他需要存储的用户信息
        header("Location: index4.php");
        exit();
    }
}
else {
        // 用户不存在，弹窗提示
        $errorMessage = "User does not exist!";
    }
}
// 关闭数据库连接
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: white;
            padding: 20px;
            font-size: 24px;
        }

        main {
            max-width: 400px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            margin-bottom: 8px;
            width: 100%;
            text-align: left;
        }

        input {
            margin-bottom: 16px;
            padding: 8px;
            width: 100%;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #555;
        }

        .error-message {
            color: red;
            margin-top: 16px;
        }

        .register-link {
            margin-top: 16px;
        }
    </style>
</head>
<body>
    <header>
        Login Form
    </header>
    <main>
        <!-- Login Form -->
        <form action="login4.php" method="post">
            <label for="lastName">Last Name:</label>
            <input type="text" name="lastName" required>
            <label for="firstName">First Name:</label>
            <input type="text" name="firstName" required>
            <button type="submit">Login</button>

            <?php
            // Show error message
            if (!empty($errorMessage)) {
                echo '<p class="error-message">' . $errorMessage . '</p>';
            }
            ?>
        </form>

        <!-- Register Link -->
        <p class="register-link">Don't have an account? <a href="register4.php">Register here</a></p>
    </main>
</body>
</html>
