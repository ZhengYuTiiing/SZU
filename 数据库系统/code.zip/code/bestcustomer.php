<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理端 - Best Customers</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: white;
            padding: 20px;
            font-size: 24px;
        }

        main {
            max-width: 1000px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .return-button {
            width: 500px; /* Adjust the width as needed */
            display: block;
            margin: 10px 0;
            padding: 10px;
            background-color: #333;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
    </style>
</head>
<body>
    <header>
        管理端 - Best Customers
    </header>
    <main>
        <h1>Best Customers 表</h1>
        <?php
        include 'conn4.php';

        // 调用存储过程
        $sql = "CALL bestcustomers()";
        $result = $conn->query($sql);

        if ($result === false) {
            echo "调用存储过程时出错: " . $conn->error;
        } else {
            // 在表格中显示结果
            echo "<table border='1'>
                <tr>
                    <th>LastName</th>
                    <th>FirstName</th>
                    <th>Address</th>
                    <th>Telephone</th>
                    <th>TotalLengthOfRentals</th>
                </tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['LastName']}</td>
                        <td>{$row['FirstName']}</td>
                        <td>{$row['Address']}</td>
                        <td>{$row['Telephone']}</td>
                        <td>{$row['TotalLengthOfRentals']}</td>
                    </tr>";
            }

            echo "</table>";

            // 添加返回按钮
            echo "<form method='get' action='customers.php'>
                    <input type='submit' value='返回 Customers' class='return-button'>
                  </form>";
        }

        // 关闭连接
        $conn->close();
        ?>
    </main>
</body>
</html>
