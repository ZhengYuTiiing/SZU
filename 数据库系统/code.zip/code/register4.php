<?php
include 'conn4.php';

// 初始化变量
$errorMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取用户输入的注册信息
    $customerID = $_POST['customerID'];
    $lastName = $_POST['lastName'];
    $firstName = $_POST['firstName'];
    $address = $_POST['address'];
    $telephone = $_POST['telephone'];
    $cellPhone = $_POST['cellPhone'];
    $emailAddress = $_POST['emailAddress'];
    $creditCard = $_POST['creditCard'];
  
    $checkUserSql = "SELECT * FROM Customers WHERE CustomerID = '$customerID'";
    $checkUserResult = $conn->query($checkUserSql);
    if ($checkUserResult->num_rows > 0) {
        // 用户已存在，弹窗提示
        $errorMessage = "User with Customer ID '$customerID' already exists!";
    }else{
         // 构造 SQL 查询语句
    $sql = "INSERT INTO Customers (CustomerID, LastName, FirstName, Address, Telephone, CellPhone, EmailAddress, CreditCard) 
    VALUES ('$customerID', '$lastName', '$firstName', '$address', '$telephone', '$cellPhone', '$emailAddress', '$creditCard')";

// 执行插入操作
if ($conn->query($sql) === TRUE) {
echo '<script>alert("Registration successful! Welcome ' . $firstName . ' ' . $lastName . '");</script>';
} else {
// 注册失败，弹窗提示
$errorMessage = "Registration failed: " . $conn->error;
}
    }
   
}

// 关闭数据库连接
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Form</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: white;
            padding: 20px;
            font-size: 24px;
        }

        main {
            max-width: 400px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            margin-bottom: 8px;
            width: 100%;
            text-align: left;
        }

        input {
            margin-bottom: 16px;
            padding: 8px;
            width: 100%;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #555;
        }

        .error-message {
            color: red;
            margin-top: 16px;
        }

        .login-link {
            margin-top: 16px;
        }
    </style>
</head>
<body>
    <header>
        Register Form
    </header>
    <main>
        <!-- Register Form -->
        <form action="register4.php" method="post">
            <label for="customerID">Customer ID:</label>
            <input type="text" name="customerID" required>

            <label for="lastName">Last Name:</label>
            <input type="text" name="lastName" required>

            <label for="firstName">First Name:</label>
            <input type="text" name="firstName" required>

            <label for="address">Address:</label>
            <input type="text" name="address" required>

            <label for="telephone">Telephone:</label>
            <input type="text" name="telephone" required>

            <label for="cellPhone">Cell Phone:</label>
            <input type="text" name="cellPhone" required>

            <label for="emailAddress">Email Address:</label>
            <input type="email" name="emailAddress" required>

            <label for="creditCard">Credit Card:</label>
            <input type="text" name="creditCard" required>

            <button type="submit">Register</button>

            <?php
            // Show error message
            if (!empty($errorMessage)) {
                echo '<p class="error-message">' . $errorMessage . '</p>';
            }
            ?>
        </form>

        <!-- Login Link -->
        <p class="login-link">Already have an account? <a href="login4.php">Login here</a></p>
    </main>
</body>
</html>
