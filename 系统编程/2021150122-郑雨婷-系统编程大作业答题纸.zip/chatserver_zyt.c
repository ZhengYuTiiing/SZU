#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h>
#include "myclientinfo.h"
#include <sys/select.h>
#include <libconfig.h>
#include <time.h>
#include <json-c/json.h>
#include <pthread.h>
pthread_t regThread, loginThread, chatThread, logoutThread;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
const char *REG_FIFO, *LOGIN_FIFO, *MSG_FIFO, *LOGOUT_FIFO, *FAIL_FIFO, *LOGFILES;
int MAX_ONLINE_USERS, MAX_LOG_PERUSER;
#define USER_NUM 10
#define BUFF_SZ 100
typedef struct
{
    char username[10];
    char password[15];
    char fifo[150];
    int login;
    int logdevice;
} USER;
USER user[USER_NUM];
char buffer[BUFF_SZ];
int now_number = 0;
int now_online = 0;
REGINFO rinfo;
LOGINFO linfo;
CHATINFO cinfo;
LOGOUTINFO loinfo;
void logEvent(const char *username, const char *logtext)
{

    char logFileName[150];
    sprintf(logFileName, "%s%s.log", LOGFILES, username);
    FILE *file = fopen(logFileName, "a");
    if (file == NULL)
    {
        perror("Fail to open log file!\n ");
    }
    // 设置超级用户具有读写权限，其他用户没有任何权限
    if (chmod(logFileName, S_IRUSR | S_IWUSR) != 0)
    {
        perror("Error setting file permissions");
        fclose(file);
        exit(EXIT_FAILURE);
    }
    time_t timep;
    time(&timep);
    fprintf(file, "%s,Time: %s\n", logtext, asctime(gmtime(&timep)));
    fclose(file);
}
void receiveOffline(char *username)
{
    char filename[150];
    sprintf(filename, "/home/zhengyuting2021150122/offline/%s", username);
    char fifo[100];
    sprintf(fifo, "/home/zhengyuting2021150122/fifo/%s", username);
    printf("myfifo=%s\n", fifo);
    FILE *file = fopen(filename, "r");
    if (file == NULL)
    {
        perror("Error opening offline file");
        return;
    }

    char line[256]; // 假设每行不超过256字符
    while (fgets(line, sizeof(line), file) != NULL)
    {
        char savedUsername[20];
        char savedMessage[100];
        char savedTime[100];

        if (sscanf(line, "%19[^|]|%99[^|]|%99[^\n]", savedUsername, savedMessage, savedTime) == 3)
        {
            char message[250];
            sprintf(message, "recieve message from %s:'%s',time:%s", savedUsername, savedMessage, savedTime);
            printf("mes:%s\n", message);
            int client_fd = open(fifo, O_WRONLY | O_NONBLOCK);
            write(client_fd, &message, sizeof(message));
            char logtext[200];
            sprintf(logtext, "[%s](True) send '%s' to %s   ", savedUsername, savedMessage, username);
            logEvent(cinfo.myname, logtext);
            memset(message, '\0', sizeof(message));
            memset(savedUsername, '\0', sizeof(savedUsername));
            memset(savedMessage, '\0', sizeof(savedMessage));
            memset(savedTime, '\0', sizeof(savedTime));
        }
    }

    fclose(file);
    remove(filename);
}
void signal_handler(int signum) {}
void daemonize()
{
    // 执行一个 fork()，之后父进程退出，子进程继续执行。
    pid_t pid = fork();
    if (pid > 0)
        exit(0);
    else if (pid < 0)
    {
        perror("fork");
        exit(0);
    }
    // 子进程调用 setsid() 开启一个新会话。
    if (setsid() == -1)
    {
        perror("setsid");
        exit(0);
    }
    // 清除进程的 umask 以确保当守护进程创建文件和目录时拥有所需的权限。
    umask(0);
    // 修改进程的当前工作目录，通常会改为根目录（/）。
    chdir("/");
    // 关闭守护进程从其父进程继承而来的所有打开着的文件描述符。
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);
    // 信号处理部分，忽略 SIGCHLD 和 SIGTERM 信号
    signal(SIGCHLD, signal_handler);
    signal(SIGTERM, signal_handler);
    // 在关闭了文件描述符0、1、2之后，守护进程通常会打开/dev/null 并使用dup2() 使所有这些描述符指向这个设备。
    open("/dev/null", O_RDWR); // stdin
    dup2(0, STDOUT_FILENO);    // stdout
    dup2(0, STDERR_FILENO);    // stderr
}
int findMax(int a, int b, int c, int d)
{
    int max = a;
    if (b > max)
    {
        max = b;
    }
    if (c > max)
    {
        max = c;
    }
    if (d > max)
    {
        max = d;
    }
    return max;
}
void broadcastLOGIN(LOGINFO linfo)
{
    char fifo[100];
    sprintf(buffer, "Received from server:%s login success! Now online number:%d \n", linfo.username, now_online);
    strcat(buffer, "Online users:");
    for (int j = 0; j < USER_NUM; j++)
    {
        if (user[j].login == 1 )
        {
            strcat(buffer, " ");
            strcat(buffer, user[j].username);
        }
    }
    for (int j = 0; j < USER_NUM; j++)
    {
        if (user[j].login == 1 && strcmp(user[j].username, linfo.username) != 0)
        {
            sprintf(fifo, "/home/zhengyuting2021150122/fifo/%s", user[j].username);
            int fd = open(fifo, O_WRONLY | O_NONBLOCK);
            write(fd, buffer, strlen(buffer) + 1);
        }
    }
}
void broadcastLOGOUT(LOGOUTINFO loinfo)
{
    char fifo[100];
    sprintf(buffer, "Received from server:%s log out success! Now online number:%d\n", loinfo.myname, now_online);
    strcat(buffer, "Online users:");
    for (int j = 0; j < USER_NUM; j++)
    {
        if (user[j].login == 1 )
        {
            strcat(buffer, " ");
            strcat(buffer, user[j].username);
        }
    }
    for (int j = 0; j < USER_NUM; j++)
    {
        if (user[j].login == 1 && strcmp(user[j].username, loinfo.myname) != 0)
        {
            sprintf(fifo, "/home/zhengyuting2021150122/fifo/%s", user[j].username);
            int fd = open(fifo, O_WRONLY | O_NONBLOCK);
            write(fd, buffer, strlen(buffer) + 1);
        }
    }
}
void *regThreadFunction(void *arg)
{
    pthread_mutex_lock(&mutex);
    USER u;
    sprintf(u.fifo, "/home/zhengyuting2021150122/fifo/%s", rinfo.username);
    strcpy(u.username, rinfo.username);
    strcpy(u.password, rinfo.password);
    u.login = 0;
    u.logdevice = 0;
    int tag = 0;
    for (int j = 0; j < USER_NUM; j++)
    {
        if (strcmp(rinfo.username, user[j].username) == 0)
        {
            sprintf(buffer, "register failed\n");
            tag = 1;
            break;
        }
    }
    if (tag == 0)
    {
        if (now_number >= USER_NUM)
        {
            sprintf(buffer, "sorry!user max!\n");
        }
        else
        {
            user[now_number] = u;
            sprintf(buffer, "Register success!\n");
            now_number++;
            char logtext[200];
            sprintf(logtext, "[%s] register success!", u.username);
            logEvent(u.username, logtext);
        }
    }
    int fail_fd = open(FAIL_FIFO, O_WRONLY | O_NONBLOCK);
    write(fail_fd, buffer, strlen(buffer) + 1);
    memset(buffer, '\0', BUFF_SZ);
    pthread_mutex_unlock(&mutex);
}
void *loginThreadFunction(void *arg)
{
    pthread_mutex_lock(&mutex);
    char client_fifo[150];
    int tag = 0;
    for (int j = 0; j < USER_NUM; j++)
    {
        if (strcmp(linfo.username, user[j].username) == 0 && strcmp(linfo.password, user[j].password) == 0 && user[j].login != 1)
        {
            if ((now_online + 1) <= MAX_ONLINE_USERS && (user[j].logdevice + 1) <= MAX_LOG_PERUSER)
            {
                user[j].login = 1;
                user[j].logdevice += 1;
                now_online++;
                tag = 1;
                break;
            }
        }
    }
    if (tag == 0)
    {
        sprintf(buffer, "Login failed!\n");
        int fail_fd = open(FAIL_FIFO, O_WRONLY | O_NONBLOCK);
        write(fail_fd, buffer, strlen(buffer) + 1);
    }
    else
    {
        sprintf(buffer, "%s login success! Now online number:%d\n", linfo.username, now_online);
        strcat(buffer, "Online users:");
        for (int j = 0; j < USER_NUM; j++)
    {
        if (user[j].login == 1 )
        {
            // 追加用户名到 buffer
            strcat(buffer, " ");
            strcat(buffer, user[j].username);
        }
    }
        char logtext[200];
        sprintf(logtext, "[%s] log in success!   ", linfo.username);
        logEvent(linfo.username, logtext);
        int fail_fd = open(FAIL_FIFO, O_WRONLY | O_NONBLOCK);
        write(fail_fd, buffer, strlen(buffer) + 1);
        broadcastLOGIN(linfo);
        // 看看有没有离线消息要接受
        char offlineFilename[100];
        sprintf(offlineFilename, "/home/zhengyuting2021150122/offline/%s", linfo.username);
        if (access(offlineFilename, F_OK) == 0)
        {
            printf("Offline messages exist for user %s\n", linfo.username);
            receiveOffline(linfo.username);
        }
    }
    pthread_mutex_unlock(&mutex);
}
void *chatThreadFunction(void *arg)
{
    pthread_mutex_lock(&mutex);
    char offlinefile[50];
    char offlineText[50];
    int tag = 0;
    for (int j = 0; j <= now_online; j++)
    {
        if (strcmp(cinfo.hisname, user[j].username) == 0)
        {
            if (user[j].login == 0)
            {
                char logtext[200];
                sprintf(logtext, "[%s](False) send '%s' to %s  ", cinfo.myname, cinfo.mes, cinfo.hisname);
                logEvent(cinfo.myname, logtext);
                printf("create offline file!\n");
                sprintf(offlinefile, "/home/zhengyuting2021150122/offline/%s", cinfo.hisname);
                printf("create offline file over!\n");
                time_t timep;
                time(&timep);
                int fd = open(offlinefile, O_WRONLY | O_CREAT | O_APPEND, 0644);
                sprintf(offlineText, "%s|%s|%s", cinfo.myname, cinfo.mes, asctime(gmtime(&timep)));
                write(fd, offlineText, strlen(offlineText));
                printf("right over!\n");
                tag = 0;
            }
            else
            {
                char message[200];
                sprintf(message, "recieve message from %s:%s", cinfo.myname, cinfo.mes);
                int client_fd = open(user[j].fifo, O_WRONLY | O_NONBLOCK);
                write(client_fd, &message, strlen(message) + 1);
                tag = 1;
                char logtext[200];
                sprintf(logtext, "[%s](True) send '%s' to %s   ", cinfo.myname, cinfo.mes, cinfo.hisname);
                logEvent(cinfo.myname, logtext);
                break;
            }
        }
    }
    if (tag == 0)
        sprintf(buffer, "Send to %s failed!\n", cinfo.hisname);
    else
    {
        sprintf(buffer, "Send to %s success!\n", cinfo.hisname);
    }
    int fail_fd = open(FAIL_FIFO, O_WRONLY | O_NONBLOCK);
    write(fail_fd, buffer, strlen(buffer) + 1);
    pthread_mutex_unlock(&mutex);
}
void *logoutThreadFunction(void *arg)
{
    pthread_mutex_lock(&mutex);
    int tag = 0;
    for (int j = 0; j < USER_NUM; j++)
    {
        if (strcmp(loinfo.myname, user[j].username) == 0 && user[j].login == 1)
        {
            user[j].login = 0;
            user[j].logdevice--;
            now_online--;
            tag = 1;
            char logtext[200];
            sprintf(logtext, "[%s] log out successful!  ", loinfo.myname);
            logEvent(loinfo.myname, logtext);
            break;
        }
    }
    if (tag == 0)
        sprintf(buffer, "Log out failed!\n");
    else
    {
        sprintf(buffer, "Log out success!\n");
        broadcastLOGOUT(loinfo);
    }
    int fail_fd = open(FAIL_FIFO, O_WRONLY | O_NONBLOCK);
    write(fail_fd, buffer, strlen(buffer) + 1);
    pthread_mutex_unlock(&mutex);
}
int main()
{
    daemonize();
    // 读取配置文件
    config_t cfg;
    config_init(&cfg);
    if (!config_read_file(&cfg, "/home/zhengyuting2021150122/config"))
    {
        fprintf(stderr, "Error while reading config file: %s\n", config_error_text(&cfg));
        config_destroy(&cfg);
        return 1;
    }
    config_lookup_string(&cfg, "Paths.REG_FIFO", &REG_FIFO);
    config_lookup_string(&cfg, "Paths.LOGIN_FIFO", &LOGIN_FIFO);
    config_lookup_string(&cfg, "Paths.MSG_FIFO", &MSG_FIFO);
    config_lookup_string(&cfg, "Paths.LOGOUT_FIFO", &LOGOUT_FIFO);
    config_lookup_string(&cfg, "Paths.FAIL_FIFO", &FAIL_FIFO);
    config_lookup_int(&cfg, "Settings.MAX_ONLINE_USERS", &MAX_ONLINE_USERS);
    config_lookup_int(&cfg, "Settings.MAX_LOG_PERUSER", &MAX_LOG_PERUSER);
    config_lookup_string(&cfg, "Paths.LOGFILES", &LOGFILES);
    printf("max_online=%d\n", MAX_ONLINE_USERS);

    for (int i = 0; i < USER_NUM; i++)
    {
        // 初始化其他字段为需要的值
        strcpy(user[i].username, "");
        strcpy(user[i].password, "");
        strcpy(user[i].fifo, "");
        user[i].login = 0;
        user[i].logdevice = 0;
    }

    int res;
    int i = 0;
    int reg_fifo_fd, login_fifo_fd, msg_fifo_fd, logout_fifo_fd, max_fd, client_fd, fail_fd;
    fd_set fds, tmp_fds;
    // 服务器这边创建5个众所周知的命名管道
    res = mkfifo(REG_FIFO, 0777);
    res = mkfifo(LOGIN_FIFO, 0777);
    res = mkfifo(MSG_FIFO, 0777);
    res = mkfifo(LOGOUT_FIFO, 0777);
    res = mkfifo(FAIL_FIFO, 0777);
    // open 四个FIFO for reading
    reg_fifo_fd = open(REG_FIFO, O_RDONLY | O_NONBLOCK);
    login_fifo_fd = open(LOGIN_FIFO, O_RDONLY | O_NONBLOCK);
    msg_fifo_fd = open(MSG_FIFO, O_RDONLY | O_NONBLOCK);
    logout_fifo_fd = open(LOGOUT_FIFO, O_RDONLY | O_NONBLOCK);
    printf("\nServer is rarin' to go!\n");
    max_fd = findMax(reg_fifo_fd, login_fifo_fd, msg_fifo_fd, logout_fifo_fd);
    FD_ZERO(&fds);
    FD_SET(reg_fifo_fd, &fds);
    FD_SET(login_fifo_fd, &fds);
    FD_SET(msg_fifo_fd, &fds);
    FD_SET(logout_fifo_fd, &fds);
    memset(buffer, '\0', BUFF_SZ);
    while (1)
    {
        tmp_fds = fds;
        select(max_fd + 1, &tmp_fds, NULL, NULL, NULL);
        // 注册请求
        if (FD_ISSET(reg_fifo_fd, &tmp_fds)){
            if (read(reg_fifo_fd, &rinfo, sizeof(REGINFO)) > 0){
                printf("receive a register info\n");
                pthread_create(&regThread, NULL, regThreadFunction, NULL);
            }
            memset(buffer, '\0', BUFF_SZ);
        }
        // 登录请求
        if (FD_ISSET(login_fifo_fd, &tmp_fds)){
            if (read(login_fifo_fd, &linfo, sizeof(LOGINFO)) > 0){
                printf("receive a login info\n");
                pthread_create(&loginThread, NULL, loginThreadFunction, NULL);
            }
            memset(buffer, '\0', BUFF_SZ);
        }
        // 聊天请求
        if (FD_ISSET(msg_fifo_fd, &tmp_fds)){
            if (read(msg_fifo_fd, &cinfo, sizeof(CHATINFO)) > 0){
                printf("receive a chat info\n");
                pthread_create(&chatThread, NULL, chatThreadFunction, NULL);
            }
            memset(buffer, '\0', BUFF_SZ);
        }
        // 注销请求
        if (FD_ISSET(logout_fifo_fd, &tmp_fds)) {
            if (read(logout_fifo_fd, &loinfo, sizeof(LOGOUTINFO)) > 0){
                printf("receive a logout info\n");
                pthread_create(&logoutThread, NULL, logoutThreadFunction, NULL);
            }
            memset(buffer, '\0', BUFF_SZ);
        }
    }
}