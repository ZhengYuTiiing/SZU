#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h>
#include "myclientinfo.h"
#include <sys/select.h>
#include <sys/wait.h>
#include <pthread.h>
#define REG_FIFO "/home/zhengyuting2021150122/fifo/zyt_register"
#define LOGIN_FIFO "/home/zhengyuting2021150122/fifo/zyt_login"
#define MSG_FIFO "/home/zhengyuting2021150122/fifo/zyt_sendmsg"
#define LOGOUT_FIFO "/home/zhengyuting2021150122/fifo/zyt_logout"
#define FAIL_FIFO "/home/zhengyuting2021150122/fifo/zyt_fail"
#define LOGFILES "/var/log/chat-logs/"
#define BUFF_SZ 250

char my_fifo_name[BUFF_SZ];
void* listenFunction(void* arg) {
    char* username = (char*)arg;
    char my_fifo_name[BUFF_SZ];
    int my_fd;
    
    // 创建FIFO名称
    sprintf(my_fifo_name, "/home/zhengyuting2021150122/fifo/%s", username);
    
    // 打开FIFO用于读取
    my_fd = open(my_fifo_name, O_RDONLY | O_NONBLOCK);

    char buffer[BUFF_SZ];
    memset(buffer, '\0', BUFF_SZ);

    while (1) {
        int res = read(my_fd, &buffer, BUFF_SZ);
        if (res > 0) {
            printf("%s\n", buffer);
            memset(buffer, '\0', BUFF_SZ);
        }
    }
    
    // 线程结束时关闭FIFO
    close(my_fd);

    return NULL;
}
void handler(int sig){
    exit(1);
}
    
int main(){
    pid_t fpid;
    int login=0;
    int res;
    int info_type=0;
    int server_fd,my_fd,fail_fd;
    char buffer[BUFF_SZ];
    char username[10]="noone";
    REGINFO rinfo;
    LOGINFO linfo;
    CHATINFO cinfo;
    LOGOUTINFO loinfo;
    fd_set fds,tmp_fds;
    //handle some signals
    signal(SIGKILL,handler);
    signal(SIGINT,handler);
    signal(SIGTERM,handler);
  
    fail_fd = open(FAIL_FIFO,O_RDONLY|O_NONBLOCK); 
    FD_ZERO(&fds);
    FD_SET(fail_fd,&fds);
    while (1)
    {
    //1代表注册，2代表登录，三代表聊天
    printf("1:regsiter  2:login  3:send message  4:log out\n");
    scanf("%d",&info_type);
    //注册请求
    if(info_type==1){
        printf("Please input username and password.\n");
        scanf("%s %s",&rinfo.username,&rinfo.password);
        //往REGFIFO中写reg请求
        server_fd = open(REG_FIFO,O_WRONLY);
        write(server_fd,&rinfo,sizeof(REGINFO));
        //注册之后监听服务器传回来的提示
        memset(buffer, '\0', BUFF_SZ);
           while (1)
        {   
            res=read(fail_fd,&buffer,BUFF_SZ);
            if(res>0){
                printf("Received from server:%s\n",buffer);
                if(strcmp(buffer,"Register success!\n")==0){
                    //创建专属FIFO
                    sprintf(my_fifo_name, "/home/zhengyuting2021150122/fifo/%s",rinfo.username);
                    strcpy(rinfo.myfifo,my_fifo_name);
                    res=mkfifo(my_fifo_name,0777);
                }
                break;
            }
        }
    }
    //登录请求
    if(info_type==2){
        //打开LOGFIFO,往LOGFIFO中写log请求
        server_fd = open(LOGIN_FIFO,O_WRONLY|O_NONBLOCK);
        printf("Please input username and password.\n");
        scanf("%s %s",&linfo.username,&linfo.password);
        write(server_fd,&linfo,sizeof(LOGINFO));
        memset(buffer, '\0', BUFF_SZ);
        while (1)
        {   
            res=read(fail_fd,&buffer,BUFF_SZ);
             //聊天请求
             if(res>0){
                printf("Received from server:%s\n",buffer);
                if(strcmp(buffer, "Login failed!\n")!=0){
                    strcpy(username,linfo.username);
                      // 创建监听线程
                pthread_t listen_thread;
                pthread_create(&listen_thread, NULL, listenFunction, (void*)&linfo.username);
                }
                break;
            }
        }
    }
    //聊天请求
    if(info_type==3){
        if(strcmp(username,"noone")==0) {
            printf("Please log in first!\n");
        }
        else{
            server_fd = open(MSG_FIFO,O_WRONLY|O_NONBLOCK);
             printf("Please input the target users (comma separated, e.g., user1,user2):\n");
            while (getchar() != '\n');
            scanf("%254[^\n]", &cinfo.hisname);

            printf("Please input the message:\n");
            while (getchar() != '\n');
            scanf("%254[^\n]", &cinfo.mes);
            // 处理多个目标用户
           
            // 分割目标用户
            char *token = strtok(cinfo.hisname, ",");
            while (token != NULL) {
                strcpy(cinfo.hisname, token);
                token = strtok(NULL, ",");
                
                // 发送聊天请求
                strcpy(cinfo.myname, username);
                write(server_fd, &cinfo, sizeof(CHATINFO));
                    while (1)
                {   
                    res=read(fail_fd,&buffer,BUFF_SZ);
                    if(res>0){
                        printf("Received from server:%s\n",buffer);
                        break;
                    }
                }
            }
        }     
    }
    //退出请求
    if(info_type==4){
        if(strcmp(username,"noone")==0) {
            printf("Please log in first!\n");
        }
        else{
            getchar();
            server_fd = open(LOGOUT_FIFO,O_WRONLY|O_NONBLOCK);
            strcpy(loinfo.myname,username);
            write(server_fd,&loinfo,sizeof(LOGOUTINFO));
            memset(buffer, '\0', BUFF_SZ);
           
              while (1)
            {   
                res=read(fail_fd,&buffer,BUFF_SZ);
                if(res>0){
                    printf("Received from server:%s\n",buffer);
                    if(strcmp(buffer,"Log out success!\n")==0){
                        strcpy(username,"noone");
                    }
                    break;
                }
            }
        }     
    }
    }   
    return 0;
}
