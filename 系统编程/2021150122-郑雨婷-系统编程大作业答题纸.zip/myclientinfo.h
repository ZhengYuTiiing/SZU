#ifndef _CLIENTINFO_H
#define _CLIENTINFO_H
typedef struct{
    char myfifo[150];
    char username[50];
    char password[50];
}REGINFO,*REGINFOPTR;
typedef struct{
    char username[50];
    char password[50];
}LOGINFO,*LOGINFOPTR;
typedef struct{
    char myname[50];
    char hisname[50];
    char mes[100];
}CHATINFO,*CHATINFOPTR;
typedef struct{
    char myname[10];
}LOGOUTINFO,*LOGOUTNFOPTR;

typedef struct{
    char myname[50];
    char hisname[50];
    char mes[100];
}FAILCHATINFO,*FAILCHATINFOPTR;
#endif