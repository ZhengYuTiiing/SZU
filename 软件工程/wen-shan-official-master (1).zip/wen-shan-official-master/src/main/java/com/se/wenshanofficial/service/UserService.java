package com.se.wenshanofficial.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.se.wenshanofficial.Entity.User;

public interface UserService extends IService<User> {
}
