package com.se.wenshanofficial.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.se.wenshanofficial.Entity.Mission;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MissionMapper extends BaseMapper<Mission> {
}
