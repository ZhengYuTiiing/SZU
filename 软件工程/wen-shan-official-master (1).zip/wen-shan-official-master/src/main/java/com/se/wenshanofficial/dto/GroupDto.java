package com.se.wenshanofficial.dto;

import com.se.wenshanofficial.Entity.Group;
import com.se.wenshanofficial.Entity.GroupMember;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class GroupDto extends Group {
    private List<GroupMember> groupMemberList = new ArrayList<>();
}
