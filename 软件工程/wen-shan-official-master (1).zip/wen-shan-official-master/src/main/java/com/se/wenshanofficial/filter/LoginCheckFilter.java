package com.se.wenshanofficial.filter;

import com.alibaba.fastjson.JSON;
import com.se.wenshanofficial.common.BaseContext;
import com.se.wenshanofficial.common.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.AntPathMatcher;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 检查用户是否已经完成登录
 */
@WebFilter(filterName = "loginCheckFilter", urlPatterns = "/*")
@Slf4j
public class LoginCheckFilter implements Filter {
    public static final AntPathMatcher PATH_MATCHER = new AntPathMatcher();
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        // 1.获取请求路径
        String requestURI = request.getRequestURI();
        // 2.设置不进行拦截的路径
        String[] urls = new String[]{
                "/user/login/{clientType}",
                "/user/logout",
                "/backend/**",
                "/front/**",
                "/common/**"
        };
        log.info("拦截到请求：{}", requestURI);

        // 3.检查是否拦截
        boolean check = check(urls, requestURI);
        // 4.不拦截直接放行
        if (check){
            log.info("本次请求{}不需要处理", requestURI);
            filterChain.doFilter(request, response);
            return;
        }

        // 5-1.管理端员工已经登录了，放行
        Object employee = request.getSession().getAttribute("user");
        if (employee != null){
            BaseContext.setCurrentId((Long)employee);
            log.info("用户已登录，用户id为：{}", employee);
            filterChain.doFilter(request, response);
            return;
        }
        // 5-2.@TODO构建普通客户端时，完成普通客户端的登录放行

        // 6.未登录，则返回前端指定的信息
        log.info("用户未登录");
        response.getWriter().write(JSON.toJSONString(Result.error("NOTLOGIN")));
    }

    /**
     * 路径匹配检查，检查是否需要放行
     * @param urls
     * @param requestURI
     * @return
     */
    public boolean check(String[] urls, String requestURI){
        for (String url : urls){
            boolean match = PATH_MATCHER.match(url, requestURI);
            if (match){
                return true;
            }
        }
        return false;
    }
}
