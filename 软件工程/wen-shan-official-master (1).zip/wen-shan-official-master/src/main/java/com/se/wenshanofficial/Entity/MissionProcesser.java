package com.se.wenshanofficial.Entity;

import lombok.Data;

@Data
public class MissionProcesser {
    private static final long serialVersionUID = 1L;

    private Long missionId;

    private Long processerId;
}
