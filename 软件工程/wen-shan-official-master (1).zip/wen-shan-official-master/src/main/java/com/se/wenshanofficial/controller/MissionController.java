package com.se.wenshanofficial.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.se.wenshanofficial.Entity.Mission;
import com.se.wenshanofficial.Entity.MissionProcesser;
import com.se.wenshanofficial.common.Result;
import com.se.wenshanofficial.dto.MissionDto;
import com.se.wenshanofficial.service.MissionProcesserService;
import com.se.wenshanofficial.service.MissionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/mission")
public class MissionController {
    @Autowired
    private MissionService missionService;

    @Autowired
    private MissionProcesserService missionProcesserService;


    /**
     * 添加任务，以及任务的处理人集合
     * @param missionDto
     * @return
     */
    @PostMapping
    public Result<String> save(@RequestBody MissionDto missionDto){
        log.info("将要添加任务的Id：{}", missionDto.getId());
        //先保存mission进表，之后获取mission的Id，用于向mission_processer中添加元组
        missionService.save(missionDto);


        List<MissionProcesser> missionProcessers = missionDto.getMissionProcessers();

        Long id = missionDto.getId();
        for (MissionProcesser missionProcesser : missionProcessers){
            missionProcesser.setMissionId(id);
        }

        missionProcesserService.saveBatch(missionProcessers);
        return Result.success("添加任务成功");
    }

    /**
     * 根据id删除任务，并将mission_processer表中的任务处理人一并删除
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    public Result<String> deleteById(@PathVariable Long id){
        LambdaQueryWrapper<MissionProcesser> missionProcesserLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        missionProcesserLambdaQueryWrapper.eq(MissionProcesser::getMissionId, id);
        missionProcesserService.remove(missionProcesserLambdaQueryWrapper);
        missionService.removeById(id);
        return Result.success("删除任务成功");
    }

    /**
     * 修改任务：先从mission_processer表中删除所有的任务处理人，再添加新的处理人集合，然后
     * 在mission表中更新任务
     * @param missionDto
     * @return
     */
    @PutMapping
    public Result<String> update(@RequestBody MissionDto missionDto){
        Long id = missionDto.getId();
        LambdaQueryWrapper<MissionProcesser> missionProcesserLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        missionProcesserLambdaQueryWrapper.eq(MissionProcesser::getMissionId, id);
        missionProcesserService.remove(missionProcesserLambdaQueryWrapper);
        missionProcesserService.saveBatch(missionDto.getMissionProcessers());

        missionService.updateById(missionDto);
        return Result.success("修改任务成功");
    }

    /**
     * 根据id查询任务及其处理人，用于前端修改任务的数据回显
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public Result<MissionDto> getById(@PathVariable Long id){
        Mission mission = missionService.getById(id);
        LambdaQueryWrapper<MissionProcesser> missionProcesserLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        missionProcesserLambdaQueryWrapper.eq(MissionProcesser::getMissionId, id);
        List<MissionProcesser> processers =
                missionProcesserService.list(missionProcesserLambdaQueryWrapper);
        MissionDto missionDto = new MissionDto();
        BeanUtils.copyProperties(mission, missionDto);
        missionDto.setMissionProcessers(processers);
        return Result.success(missionDto);
    }

    /**
     * 根据截止日期查询任务
     * @param mission
     * @return
     */
    @PostMapping("/getByDeadline")
    public Result<List<MissionDto>> getByDeadline(@RequestBody Mission mission){
        LambdaQueryWrapper<Mission> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        LocalDateTime deadline = mission.getDeadline();
        lambdaQueryWrapper.eq(Mission::getDeadline, deadline);
        List<Mission> missions = missionService.list(lambdaQueryWrapper);
        List<MissionDto> missionDtos = new LinkedList<>();
        for (Mission missionInDB : missions){
            LambdaQueryWrapper<MissionProcesser> missionProcesserLambdaQueryWrapper =
                    new LambdaQueryWrapper<>();
            missionProcesserLambdaQueryWrapper.eq(MissionProcesser::getMissionId,
                    missionInDB.getId());
            List<MissionProcesser> missionProcessers =
                    missionProcesserService.list(missionProcesserLambdaQueryWrapper);
            MissionDto missionDto = new MissionDto();
            BeanUtils.copyProperties(missionInDB, missionDto);
            missionDto.setMissionProcessers(missionProcessers);
            missionDtos.add(missionDto);
        }
        return Result.success(missionDtos);
    }
}
