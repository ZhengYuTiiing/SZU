package com.se.wenshanofficial.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.se.wenshanofficial.Entity.MissionProcesser;
import com.se.wenshanofficial.Mapper.MissionProcesserMapper;
import com.se.wenshanofficial.service.MissionProcesserService;
import org.springframework.stereotype.Service;

@Service
public class MissionProcesserServiceImpl extends ServiceImpl<MissionProcesserMapper, MissionProcesser> implements MissionProcesserService {
}
