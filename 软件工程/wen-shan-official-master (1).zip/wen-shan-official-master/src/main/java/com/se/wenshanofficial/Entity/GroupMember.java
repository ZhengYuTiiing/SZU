package com.se.wenshanofficial.Entity;

import lombok.Data;

@Data
public class GroupMember {
    private static final long serialVersionUID = 1L;

    private Long groupId;

    private Long memberId;
}
