package com.se.wenshanofficial.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.se.wenshanofficial.Entity.GroupMember;
import com.se.wenshanofficial.Entity.MissionProcesser;
import com.se.wenshanofficial.Entity.User;
import com.se.wenshanofficial.common.Result;
import com.se.wenshanofficial.service.GroupMemberService;
import com.se.wenshanofficial.service.MissionProcesserService;
import com.se.wenshanofficial.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private GroupMemberService groupMemberService;

    @Autowired
    private MissionProcesserService missionProcesserService;

    /**
     * 登录
     * @param request
     * @param clientType 客户端类型：0小程序普通客户端，1web管理客户端
     * @param user
     * @return
     */
    @PostMapping("/login/{clientType}")
    public Result<User> login(HttpServletRequest request, @PathVariable Integer clientType, @RequestBody User user){
        // 将密码md5加密，方便后续与数据库对比
        String password = user.getPassword();
        password = DigestUtils.md5DigestAsHex(password.getBytes());

        // 根据用户名查询用户
        LambdaQueryWrapper<User> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(User::getUsername, user.getUsername());
        User one = userService.getOne(lambdaQueryWrapper);

        // 用户名错误
        if (one == null){
            return Result.error("登录失败：用户名或密码错误");
        }

        // 密码错误
        if (!password.equals(one.getPassword())){
            return Result.error("登录失败：用户名或密码错误");
        }

        // 权限错误
        if (clientType == 1 && one.getIsAdmin() == 0){
            return Result.error("登录失败：用户没有登录管理端的权限");
        }

        // 登录成功
        request.getSession().setAttribute("user", one.getId());
        return Result.success(one);
    }

    /**
     * 退出
     * @param request
     * @return
     */
    @PostMapping("/logout")
    public Result<String> logout(HttpServletRequest request){
        request.getSession().removeAttribute("user");
        return Result.success("退出成功");
    }

    /**
     * 新增用户,  工号自动生成， 初始密码123456， 默认不是管理员
     * @param user
     * @return
     */
    @PostMapping
    public Result<String> save(@RequestBody User user){
        log.info("新增用户，用户信息{}", user.toString());
        user.setPassword("123456");
        user.setPassword(DigestUtils.md5DigestAsHex(user.getPassword().getBytes()));
        user.setIsAdmin(0);
        userService.save(user);
        return Result.success("新增用户成功");
    }

    /**
     * 按id删除用户
     * @param id
     * @return
     */
    @DeleteMapping
    public Result<String> delete(Long id){
        log.info("删除用户{}", id);
        userService.removeById(id);
        // 删除员工前将其从对应的群组，任务中删除.
        LambdaQueryWrapper<MissionProcesser> missionProcesserLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        missionProcesserLambdaQueryWrapper.eq(MissionProcesser::getProcesserId, id);
        missionProcesserService.remove(missionProcesserLambdaQueryWrapper);

        LambdaQueryWrapper<GroupMember> groupMemberLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        groupMemberLambdaQueryWrapper.eq(GroupMember::getMemberId, id);
        groupMemberService.remove(groupMemberLambdaQueryWrapper);

        return Result.success("删除用户成功");
    }

    /**
     *  按id修改用户信息,id不可变
     * @param user
     * @return
     */
    @PutMapping
    public Result<String> update(@RequestBody User user){
        log.info(user.toString());
        if (user.getPassword() != null){
            user.setPassword(DigestUtils.md5DigestAsHex(user.getPassword().getBytes()));
        }
        userService.updateById(user);
        return Result.success("修改用户信息成功");
    }

    /**
     *  员工分页列表
     * @param page 页码
     * @param pageSize 一页数量
     * @param name 员工姓名模糊查询，可为空
     * @return
     */
    @GetMapping("/page")
    public Result<Page> page(int page, int pageSize, String name){
        log.info("page = {}, pageSize = {}, name = {}", page, pageSize, name);

        // 分页构造器
        Page pageInfo = new Page(page, pageSize);
        // 条件构造器
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper();
        // 过滤条件
        queryWrapper.like(StringUtils.isNotEmpty(name), User::getName, name);


        userService.page(pageInfo, queryWrapper);
        return Result.success(pageInfo);
    }

    /**
     * 通过id获取用户信息，用于修改用户信息时的回显
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public Result<User> getById(@PathVariable Long id){
        log.info("查询用户{}", id);
        User user = userService.getById(id);
        return Result.success(user);
    }

    @GetMapping("/list")
    public Result<List<User>> list(User user){
        List<User> users = userService.list();
        return Result.success(users);
    }
}













