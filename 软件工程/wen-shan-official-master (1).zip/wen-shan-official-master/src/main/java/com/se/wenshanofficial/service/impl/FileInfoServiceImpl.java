package com.se.wenshanofficial.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.se.wenshanofficial.Entity.FileInfo;
import com.se.wenshanofficial.Mapper.FileInfoMapper;
import com.se.wenshanofficial.service.FileInfoService;
import org.springframework.stereotype.Service;

@Service
public class FileInfoServiceImpl extends ServiceImpl<FileInfoMapper, FileInfo> implements FileInfoService {
}
