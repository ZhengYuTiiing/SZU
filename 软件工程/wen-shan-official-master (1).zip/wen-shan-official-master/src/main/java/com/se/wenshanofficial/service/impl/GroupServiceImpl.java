package com.se.wenshanofficial.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.se.wenshanofficial.Entity.Group;
import com.se.wenshanofficial.Mapper.GroupMapper;
import com.se.wenshanofficial.service.GroupService;
import org.springframework.stereotype.Service;

@Service
public class GroupServiceImpl extends ServiceImpl<GroupMapper, Group> implements GroupService {
}
