package com.se.wenshanofficial.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.se.wenshanofficial.Entity.Group;
import com.se.wenshanofficial.Entity.GroupMember;
import com.se.wenshanofficial.Entity.User;
import com.se.wenshanofficial.common.Result;
import com.se.wenshanofficial.dto.GroupDto;
import com.se.wenshanofficial.service.GroupMemberService;
import com.se.wenshanofficial.service.GroupService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/group")
public class GroupController {
    @Autowired
    private GroupService groupService;

    @Autowired
    private GroupMemberService groupMemberService;

    /**
     * 以群组管理员，群组名称和群组成员集合添加一个群组
     * @param groupDto
     * @return
     */
    @PostMapping
    public Result<String> save(@RequestBody GroupDto groupDto){
        groupService.save(groupDto);
        Long groupId = groupDto.getId();
        // 将组长存入
        GroupMember admin = new GroupMember();
        admin.setMemberId(groupDto.getAdminId());
        admin.setGroupId(groupId);
        // 将group在数据库中的id赋给group_member中的对应元组
        List<GroupMember> groupMemberList = groupDto.getGroupMemberList();
        for (int i = 0;i < groupMemberList.size();i++){
            if (groupMemberList.get(i).getMemberId().equals(admin.getMemberId())){
                break;
            }else if (i == groupMemberList.size() - 1){
                groupMemberList.add(admin);
            }
        }
        for (GroupMember groupMember : groupMemberList){
            groupMember.setGroupId(groupId);
        }
        // 将其他群成员存入
        groupMemberService.saveBatch(groupMemberList);
        return Result.success("添加群组成功");
    }

    /**
     * 先删除群组内的成员，再删除群组
     * @param id
     * @return
     */
    @DeleteMapping
    public Result<String> deleteById(Long id){
        LambdaQueryWrapper<GroupMember> groupMemberLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        groupMemberLambdaQueryWrapper.eq(GroupMember::getGroupId, id);
        groupMemberService.remove(groupMemberLambdaQueryWrapper);
        groupService.removeById(id);
        return Result.success("删除群组成功");
    }

    /**
     * 修改群组
     * @param groupDto
     * @return
     */
    @PutMapping
    public Result<String> update(@RequestBody GroupDto groupDto){
        Long id = groupDto.getId();
        LambdaQueryWrapper<GroupMember> groupMemberLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        groupMemberLambdaQueryWrapper.eq(GroupMember::getGroupId, id);
        groupMemberService.remove(groupMemberLambdaQueryWrapper);
        GroupMember admin = new GroupMember();
        admin.setGroupId(id);
        admin.setMemberId(groupDto.getAdminId());
        List<GroupMember> groupMemberList = groupDto.getGroupMemberList();
        for (int i = 0;i < groupMemberList.size();i++){
            if (groupMemberList.get(i).getMemberId().equals(admin.getMemberId())){
                break;
            }else if (i == groupMemberList.size() - 1){
                groupMemberList.add(admin);
            }
        }
        groupMemberService.saveBatch(groupDto.getGroupMemberList());

        groupService.updateById(groupDto);
        return Result.success("修改群组成功");
    }

    /**
     * 分页查询群组
     * @param page
     * @param pageSize
     * @param name
     * @return
     */
    @GetMapping("/page")
    public Result<Page> page(int page, int pageSize, String name){
        Page pageInfo = new Page(page, pageSize);
        LambdaQueryWrapper<Group> groupLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        groupLambdaQueryWrapper.like(StringUtils.isNotEmpty(name), Group::getName, name);
        groupLambdaQueryWrapper.orderByDesc(Group::getUpdateTime);
        groupService.page(pageInfo, groupLambdaQueryWrapper);
        return Result.success(pageInfo);
    }

    /**
     * 根据id查询群组及成员信息，用于点击群组栏查看成员和修改群组时的数据回显
     * @param groupId
     * @return
     */
    @GetMapping("/{groupId}")
    public Result<GroupDto> getByGroupId(@PathVariable Long groupId){
        LambdaQueryWrapper<GroupMember> groupMemberLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        groupMemberLambdaQueryWrapper.eq(GroupMember::getGroupId, groupId);
        List<GroupMember> groupMembers = groupMemberService.list(groupMemberLambdaQueryWrapper);

        Group group = groupService.getById(groupId);
        GroupDto groupDto = new GroupDto();
        BeanUtils.copyProperties(group, groupDto);
        groupDto.setGroupMemberList(groupMembers);
        return Result.success(groupDto);
    }

    /**
     * 查询群组列表，用于前端下拉选择
     * @return
     */
    @GetMapping("/list")
    public Result<List<Group>> list(){
        List<Group> groups = groupService.list();
        return Result.success(groups);
    }
}
