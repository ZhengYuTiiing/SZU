package com.se.wenshanofficial.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.se.wenshanofficial.Entity.FileInfo;

public interface FileInfoService extends IService<FileInfo> {
}
