package com.se.wenshanofficial.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.se.wenshanofficial.Entity.FileInfo;
import com.se.wenshanofficial.Entity.Group;
import com.se.wenshanofficial.common.Result;
import com.se.wenshanofficial.service.FileInfoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.UUID;

/**
 * 进行文件的上传与下载
 */
@Slf4j
@RestController
@RequestMapping("/file")
public class FileController {

    @Value("${wenshan.paths.file-path}")
    private String basePath;

    @Autowired
    private FileInfoService fileInfoService;

    /**
     * 上传文件
     * @param file 文件本身
     * @param status 文件的状态，上传头像等时url中写死为0，上传共享文件时url中写死为1
     * @param groupId 此参数可为空，当文件为共享文件时，此参数记录文件所共享的群组的id，小程序端可根据当前页面记录的group_id来传参
     * @return
     */
    @PostMapping("/upload")
    public Result<String> upload(MultipartFile file, int status, Long groupId){
        // file是临时文件，请求结束后，file会被删除。所以上传文件主要的任务既是将文件转存到其他路径当中
        log.info(file.toString());

        // 获取原始文件名
        String originalFilename = file.getOriginalFilename();
        // 文件后缀
        String suffix = originalFilename.substring(originalFilename.lastIndexOf("."));
        // 使用UUID重新生成文件名，防止名称重复造成文件覆盖
        String fileName = UUID.randomUUID().toString();

        // 将文件的对应信息存入数据库
        FileInfo fileInfo = new FileInfo();
        originalFilename = originalFilename.replace(suffix, "");
        fileInfo.setName(originalFilename);
        fileInfo.setFileName(fileName);
        fileInfo.setSuffix(suffix);
        fileInfo.setStatus(status);
        if (status == 1){
            fileInfo.setGroupId(groupId);
        }
        fileInfoService.save(fileInfo);

        fileName = fileName + suffix;
        // 创建一个目录对象
        File dir = new File(basePath);
        if (!dir.exists()){
            dir.mkdirs();
        }

        try {
            // 将临时文件转存到指定位置
            file.transferTo(new File(basePath + fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }

        return Result.success(fileName);
    }

    /**
     * 文件下载:保存到本地磁盘
     * @param response
     * @param id
     */
    @GetMapping("/download")
    public void downLoad(HttpServletResponse response, Long id){
        try {
            FileInfo fileInfo = fileInfoService.getById(id);
            String name = fileInfo.getName();
            String fileName = fileInfo.getFileName();
            String suffix = fileInfo.getSuffix();
            name += suffix;
            fileName += suffix;
            // 输入流，读取文件内容
            File file = new File(basePath + fileName);
            FileInputStream fileInputStream = new FileInputStream(file);
            // 输出流，将文件写回浏览器
            ServletOutputStream outputStream = response.getOutputStream();

            // 设置 HTTP 响应头
            response.setContentType(getContentType(fileName));
            response.setHeader("Content-Disposition", "attachment; filename=\"" + name + "\"");

            int len = 0;
            byte[] bytes = new byte[1024];
            while ((len = fileInputStream.read(bytes)) != - 1) {
                outputStream.write(bytes, 0, len);
                outputStream.flush();
            }
            outputStream.close();
            fileInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getContentType(String fileName) throws IOException {
        String contentType = "application/octet-stream"; // 默认的 MIME 类型
        String fileExtension = fileName.substring(fileName.lastIndexOf(".") + 1); // 获取文件扩展名
        contentType = Files.probeContentType(new File(fileName).toPath());
        return contentType;
    }

    /**
     * 文件下载:保存到浏览器缓存,主要用于头像等动态资源图片的显示
     * @param response
     */
    @GetMapping("/downloadToBrowser")
    public void downLoadToBrowser(HttpServletResponse response, Long id){
        try {
            FileInfo fileInfo = fileInfoService.getById(id);
            String fileName = fileInfo.getFileName();
            String suffix = fileInfo.getSuffix();
            fileName += suffix;
            // 输入流，读取文件内容
            FileInputStream fileInputStream = new FileInputStream(new File(basePath + fileName));
            // 输出流，将文件写回浏览器
            ServletOutputStream outputStream = response.getOutputStream();
            response.setContentType("image/jpeg");
            int len = 0;
            byte[] bytes = new byte[1024];
            while ((len = fileInputStream.read(bytes)) != - 1) {
                outputStream.write(bytes, 0, len);
                outputStream.flush();
            }
            outputStream.close();
            fileInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 文件信息分页查询，name可为空
     * @param page
     * @param pageSize
     * @param name
     * @return
     */
    @GetMapping("/page")
    public Result<Page> page(int page, int pageSize, String name){
        Page pageInfo = new Page(page, pageSize);
        LambdaQueryWrapper<FileInfo> groupLambdaQueryWrapper =
                new LambdaQueryWrapper<>();
        groupLambdaQueryWrapper.like(StringUtils.isNotEmpty(name), FileInfo::getName, name);
        groupLambdaQueryWrapper.orderByDesc(FileInfo::getCreateTime);
        fileInfoService.page(pageInfo, groupLambdaQueryWrapper);
        return Result.success(pageInfo);
    }

    /**
     * 删除文件
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    public Result<String> delete(@PathVariable Long id){
        // 将文件在本地删除,再将文件信息表中的数据删除
        FileInfo fileInfo = fileInfoService.getById(id);
        String fileName = fileInfo.getFileName();
        String suffix = fileInfo.getSuffix();
        new File(basePath + fileName + suffix).delete();

        fileInfoService.removeById(id);
        return Result.success("文件删除成功");
    }

}
