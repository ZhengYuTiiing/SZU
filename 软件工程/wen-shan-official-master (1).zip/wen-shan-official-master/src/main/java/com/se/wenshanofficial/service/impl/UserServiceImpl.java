package com.se.wenshanofficial.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.se.wenshanofficial.Entity.User;
import com.se.wenshanofficial.Mapper.UserMapper;
import com.se.wenshanofficial.service.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService{
}
