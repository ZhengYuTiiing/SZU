package com.se.wenshanofficial.Entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("file")
public class FileInfo {
    private static final long serialVersionUID = 1L;

    // 文件id
    private Long id;

    // 文件的名称
    private String name;

    // 后台存储的文件名
    private String fileName;

    // 文件后缀名
    private String suffix;

    //创建时间
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    //更新时间
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    //创建人
    @TableField(fill = FieldFill.INSERT)
    private Long createUser;

    //修改人
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Long updateUser;

    // 0:头像等动态资源文件1：共享的文件
    private int status;

    // 所属群组的id
    private Long groupId;
}
