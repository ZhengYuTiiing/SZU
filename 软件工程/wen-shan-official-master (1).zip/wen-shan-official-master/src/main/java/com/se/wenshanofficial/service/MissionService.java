package com.se.wenshanofficial.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.se.wenshanofficial.Entity.Mission;

public interface MissionService extends IService<Mission> {
}
