package com.se.wenshanofficial.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.se.wenshanofficial.Entity.GroupMember;
import com.se.wenshanofficial.Mapper.GroupMemberMapper;
import com.se.wenshanofficial.service.GroupMemberService;
import org.springframework.stereotype.Service;

@Service
public class GroupMemberServiceImpl extends ServiceImpl<GroupMemberMapper, GroupMember> implements GroupMemberService {
}
