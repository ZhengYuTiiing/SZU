package com.se.wenshanofficial.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLIntegrityConstraintViolationException;

/**
 * 全局异常处理
 */
@ControllerAdvice(annotations = {RestController.class, Controller.class})
@ResponseBody
@Slf4j
public class GlobalExceptionHandler {

    /**
     * 进行异常处理的方法
     * @return
     */
    @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
    public Result<String> exceptionHandler(SQLIntegrityConstraintViolationException exception){
        String exceptionMessage = exception.getMessage();
        log.error(exceptionMessage);
        if (exceptionMessage.contains("Duplicate entry")){
            String username = exceptionMessage.split(" ")[2];
            String msg = username + "已存在";
            return Result.error(msg);
        }

        return Result.error("未知错误");
    }

    /**
     * 进行异常处理的方法
     * @return
     */
    @ExceptionHandler(com.se.wenshanofficial.common.CustomException.class)
    public Result<String> exceptionHandler(com.se.wenshanofficial.common.CustomException exception){
        String exceptionMessage = exception.getMessage();
        log.error(exceptionMessage);
        return Result.error(exceptionMessage);
    }
}
