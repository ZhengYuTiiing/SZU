package com.se.wenshanofficial.dto;

import com.se.wenshanofficial.Entity.Mission;
import com.se.wenshanofficial.Entity.MissionProcesser;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class MissionDto extends Mission {
    private List<MissionProcesser> missionProcessers = new ArrayList<>();
}
