package com.se.wenshanofficial.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.se.wenshanofficial.Entity.Group;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface GroupMapper extends BaseMapper<Group> {
}
