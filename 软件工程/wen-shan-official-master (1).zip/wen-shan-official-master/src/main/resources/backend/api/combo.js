// 查询列表数据
const getSetmealPage = (params) => {
  return $axios({
    url: '/group/page',
    method: 'get',
    params
  })
}

// 删除数据接口
const deleteSetmeal = (id) => {
  return $axios({
    url: '/group',
    method: 'delete',
    params: { id }
  })
}

// 修改数据接口
const editSetmeal = (params) => {
  return $axios({
    url: '/group',
    method: 'put',
    data: { ...params }
  })
}

// 新增数据接口
const addSetmeal = (params) => {
  return $axios({
    url: '/group',
    method: 'post',
    data: { ...params }
  })
}

// 查询详情接口
const querySetmealById = (id) => {
  return $axios({
    url: `/group/${id}`,
    method: 'get'
  })
}

// 批量起售禁售
const setmealStatusByStatus = (params) => {
  return $axios({
    url: `/setmeal/status/${params.status}`,
    method: 'post',
    params: { ids: params.ids }
  })
}

// 获取群组列表
const getGroupList = (params) => {
  return $axios({
    url: '/group/list',
    method: 'get',
    params
  })
}
