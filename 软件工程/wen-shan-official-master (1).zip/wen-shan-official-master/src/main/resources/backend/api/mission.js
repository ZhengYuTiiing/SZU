function addMission (params) {
    return $axios({
        url: '/mission',
        method: 'post',
        data: { ...params }
    })
}

function getMissionsByDeadline (params) {
    return $axios({
        url: '/mission/getByDeadline',
        method: 'post',
        data: { ...params }
    })
}

const getMissionById = (id) => {
    return $axios({
        url: `/mission/${id}`,
        method: 'get'
    })
}