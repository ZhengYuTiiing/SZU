function loginApi(data) {
  return $axios({
    'url': '/user/login/1',
    'method': 'post',
    data
  })
}

function logoutApi(){
  return $axios({
    'url': '/user/logout',
    'method': 'post',
  })
}
