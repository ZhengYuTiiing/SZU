#include "Angel.h"
#include "TriMesh.h"

#include <vector>
#include <string>

const int X_AXIS = 0;
const int Y_AXIS = 1;
const int Z_AXIS = 2;
bool pause = true;;
int AXIS = 0;
const double DEFAULT_DELTA = 0.5;	// 默认的Delta值
double rotateDelta = DEFAULT_DELTA;


glm::vec3 rotateTheta(0.0, 0.0, 0.0);    // 旋转控制变量

int mainWindow;

struct openGLObject
{
	// 顶点数组对象
	GLuint vao;
	// 顶点缓存对象
	GLuint vbo;

	// 着色器程序
	GLuint program;
	// 着色器文件
	std::string vshader;
	std::string fshader;
	// 着色器变量
	GLuint pLocation;
	GLuint cLocation;
	GLuint matrixLocation;
	GLuint darkLocation;
};

openGLObject cow_object;

TriMesh* cow = new TriMesh();

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

void bindObjectAndData(TriMesh* mesh, openGLObject& object, const std::string& vshader, const std::string& fshader) {

	// 创建顶点数组对象
	glGenVertexArrays(1, &object.vao);  	// 分配1个顶点数组对象
	glBindVertexArray(object.vao);  	// 绑定顶点数组对象

	// 创建并初始化顶点缓存对象
	glGenBuffers(1, &object.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, object.vbo);
	glBufferData(GL_ARRAY_BUFFER,
		mesh->getPoints().size() * sizeof(glm::vec3) + mesh->getColors().size() * sizeof(glm::vec3),
		NULL,
		GL_STATIC_DRAW);

	// @TODO: Task3-修改完TriMesh.cpp的代码成后再打开下面注释，否则程序会报错
	glBufferSubData(GL_ARRAY_BUFFER, 0, mesh->getPoints().size() * sizeof(glm::vec3), &mesh->getPoints()[0]);
	glBufferSubData(GL_ARRAY_BUFFER, mesh->getPoints().size() * sizeof(glm::vec3), mesh->getColors().size() * sizeof(glm::vec3), &mesh->getColors()[0]);

	object.vshader = vshader;
	object.fshader = fshader;
	object.program = InitShader(object.vshader.c_str(), object.fshader.c_str());

	// 从顶点着色器中初始化顶点的位置
	object.pLocation = glGetAttribLocation(object.program, "vPosition");
	glEnableVertexAttribArray(object.pLocation);
	glVertexAttribPointer(object.pLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

	// 从顶点着色器中初始化顶点的颜色
	object.cLocation = glGetAttribLocation(object.program, "vColor");
	glEnableVertexAttribArray(object.cLocation);
	glVertexAttribPointer(object.cLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(mesh->getPoints().size() * sizeof(glm::vec3)));

	// 获得矩阵存储位置
	object.matrixLocation = glGetUniformLocation(object.program, "matrix");

}

void init()
{
	std::string vshader, fshader;
	// 读取着色器并使用
	vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";

	cow->readOff("./Models/cow.off");
	bindObjectAndData(cow, cow_object, vshader, fshader);

	// 黑色背景
	glClearColor(0.0, 0.0, 0.0, 1.0);
}

void display()
{
	// 清理窗口
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glUseProgram(cow_object.program);
	glBindVertexArray(cow_object.vao);
	// 初始化变换矩阵
	glm::mat4 m(1.0, 0.0, 0.0, 0.0,
		0.0, 1.0, 0.0, 0.0,
		0.0, 0.0, 1.0, 0.0,
		0.0, 0.0, 0.0, 1.0);
	// 调用函数传入三种变化的变化量，累加得到变化矩阵
	// 注意三种变化累加的顺序
	m = glm::rotate(m, glm::radians(rotateTheta.x), glm::vec3(1.0f, 0.0f, 0.0f));
	m = glm::rotate(m, glm::radians(rotateTheta.y), glm::vec3(0.0f, 1.0f, 0.0f));
	m = glm::rotate(m, glm::radians(rotateTheta.z), glm::vec3(0.0f, 0.0f, 1.0f));
	// 从指定位置matrixLocation中传入变换矩阵m
	glUniformMatrix4fv(cow_object.matrixLocation, 1, GL_FALSE, glm::value_ptr(m));
	// 绘制立方体中的各个三角形
	glDrawArrays(GL_TRIANGLES, 0, cow->getPoints().size());
}

// 通过Delta值更新Theta
void updateTheta(int axis, int sign) {
	rotateTheta[axis] += sign * rotateDelta;
}

// 复原Theta和Delta
void resetTheta()
{
	rotateTheta = glm::vec3(0.0, 0.0, 0.0);
	pause = true;
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
	{
		pause = false;
	}
	else if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
	{
		pause = true;
	}

}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	switch (key)
	{
		// 退出。
	case GLFW_KEY_ESCAPE:
		if (action == GLFW_PRESS) glfwSetWindowShouldClose(window, GL_TRUE);
		break;
		// T: 所有值重置。
	case GLFW_KEY_T:
		if (action == GLFW_PRESS) resetTheta();
		break;

	case GLFW_KEY_X:
		if (action == GLFW_PRESS || action == GLFW_REPEAT) AXIS = X_AXIS;
		break;
	case GLFW_KEY_Y:
		if (action == GLFW_PRESS || action == GLFW_REPEAT) AXIS = Y_AXIS;
		break;
	case GLFW_KEY_Z:
		if (action == GLFW_PRESS || action == GLFW_REPEAT) AXIS = Z_AXIS;
		break;

	}
}

void printHelp() {
	printf("Keyboard options:\n");
	printf("e: Escape\n");
	printf("x: Rotate around the x-axis\n");
	printf("y: Rotate around the y-axis\n");
	printf("z: Rotate around the z-axis\n");
	printf("t: Reset all transformations and deltas\n");
	printf("Left click to start.\n");
	printf("Right click to pause.\n");
}

void cleanData() {
	cow->cleanData();
	// 释放内存
	delete cow;
	cow = NULL;
	// 删除绑定的对象
	glDeleteVertexArrays(1, &cow_object.vao);
	glDeleteBuffers(1, &cow_object.vbo);
	glDeleteProgram(cow_object.program);
}

int main(int argc, char** argv)
{
	// 初始化GLFW库，必须是应用程序调用的第一个GLFW函数
	glfwInit();

	// 配置GLFW
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// 配置窗口属性
	GLFWwindow* window = glfwCreateWindow(600, 600, "20211510122_郑雨婷实验二", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetKeyCallback(window, key_callback);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);

	// 调用任何OpenGL的函数之前初始化GLAD
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	init();
	// 输出帮助信息
	printHelp();
	// 启用深度测试
	clock_t start, end;
	start = clock();
	glEnable(GL_DEPTH_TEST);
	while (!glfwWindowShouldClose(window))
	{
		display();
		end = clock();
		if (end - start >= 5 && !pause) {
			updateTheta(AXIS, 1);
			start = end;
		}
		// 交换颜色缓冲 以及 检查有没有触发什么事件（比如键盘输入、鼠标移动等）
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	cleanData();

	return 0;
}